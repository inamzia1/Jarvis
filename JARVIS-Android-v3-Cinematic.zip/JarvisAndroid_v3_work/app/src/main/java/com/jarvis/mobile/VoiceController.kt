package com.jarvis.mobile

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class VoiceController(
    private val activity: Activity,
    private val onFinalText: (String) -> Unit,
    private val onPartialText: (String) -> Unit = {},
    private val onStatus: (String) -> Unit
) {
    private var recognizer: SpeechRecognizer? = null
    private var continuousMode = false
    private var listening = false

    fun start() {
        continuousMode = false
        startInternal()
    }

    fun startContinuous() {
        continuousMode = true
        startInternal()
    }

    fun stopContinuous() {
        continuousMode = false
        recognizer?.stopListening()
        listening = false
        onStatus("Ready")
    }

    fun isContinuous(): Boolean = continuousMode

    private fun startInternal() {
        if (ContextCompat.checkSelfPermission(activity, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(activity, arrayOf(Manifest.permission.RECORD_AUDIO), 21)
            onStatus("Microphone permission requested")
            return
        }

        if (!SpeechRecognizer.isRecognitionAvailable(activity)) {
            onStatus("Speech recognition unavailable")
            return
        }

        if (recognizer == null) createRecognizer()
        if (listening) return

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-GB")
        }

        try {
            recognizer?.startListening(intent)
            listening = true
            onStatus("Listening")
        } catch (_: Exception) {
            listening = false
            onStatus("Voice unavailable")
        }
    }

    private fun createRecognizer() {
        recognizer = SpeechRecognizer.createSpeechRecognizer(activity).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { onStatus("Listening") }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { onStatus("Processing") }

                override fun onError(error: Int) {
                    listening = false
                    onStatus("Ready")
                    if (continuousMode) {
                        activity.window.decorView.postDelayed({ startInternal() }, 700)
                    }
                }

                override fun onResults(results: Bundle?) {
                    listening = false
                    results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        ?.trim()
                        ?.takeIf { it.isNotBlank() }
                        ?.let(onFinalText)
                    onStatus("Ready")
                    if (continuousMode) {
                        activity.window.decorView.postDelayed({ startInternal() }, 900)
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        ?.trim()
                        ?.takeIf { it.isNotBlank() }
                        ?.let(onPartialText)
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
    }

    fun destroy() {
        continuousMode = false
        recognizer?.destroy()
        recognizer = null
    }
}
