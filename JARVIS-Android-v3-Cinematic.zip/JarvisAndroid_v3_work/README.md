# JARVIS Android v3 — Cinematic Assistant

Movie-inspired Android assistant with a futuristic HUD, voice, AI planning,
vision, files, media, notifications, calendar/reminders and a local business command center.

The speech profile is a calm British cinematic AI voice using Android TTS.
It intentionally does not clone or impersonate the actor who voiced JARVIS in the films.

## Highlights
- Cinematic HUD and energy-orb interface
- live partial speech transcript
- final-only command execution
- optional continuous listening while the app is open
- UK English TTS tuning
- AI brain with structured tool plans and confirmation gates
- notifications, calendar, reminders, media, files and vision
- device battery/network/memory status
- local CRM lead pipeline and business tasks
- combined daily briefing

## Android limits
Android sandboxing and permission rules still apply. The app cannot silently
obtain unrestricted control of protected apps, private system storage or other
restricted functions. Sensitive actions remain confirmation-gated.

## Remote AI
For broad conversational intelligence, connect Brain Settings to a backend you
control. Keep AI-provider API secrets on the server, not in the APK.
