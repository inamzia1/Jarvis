package com.jarvis.mobile

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class RemoteJarvisBrain {

    fun plan(
        mode: BrainMode.Remote,
        input: String,
        memory: List<BrainTurn>
    ): Result<BrainPlan> {
        return try {
            val connection = URL(mode.endpoint).openConnection() as HttpURLConnection
            connection.requestMethod = "POST"
            connection.connectTimeout = 20_000
            connection.readTimeout = 40_000
            connection.doOutput = true
            connection.setRequestProperty("Content-Type", "application/json")

            mode.bearerToken?.let {
                connection.setRequestProperty("Authorization", "Bearer $it")
            }

            val body = JSONObject().apply {
                put("input", input)
                put("tools", BrainToolRegistry.asJson())
                put(
                    "memory",
                    JSONArray().apply {
                        memory.takeLast(12).forEach { turn ->
                            put(
                                JSONObject()
                                    .put("role", turn.role)
                                    .put("text", turn.text)
                            )
                        }
                    }
                )
                put(
                    "policy",
                    JSONObject()
                        .put("require_approval_for_medium", true)
                        .put("require_approval_for_high", true)
                        .put("max_tool_calls", 8)
                )
            }

            connection.outputStream.use {
                it.write(body.toString().toByteArray(Charsets.UTF_8))
            }

            val code = connection.responseCode
            val stream =
                if (code in 200..299) connection.inputStream
                else connection.errorStream

            val responseText = BufferedReader(
                InputStreamReader(stream)
            ).use { it.readText() }

            if (code !in 200..299) {
                return Result.failure(
                    IllegalStateException(
                        "Brain backend returned HTTP $code: $responseText"
                    )
                )
            }

            val json = JSONObject(responseText)
            val reply = json.optString(
                "reply",
                "I prepared a plan."
            )

            val calls = mutableListOf<BrainToolCall>()
            val arr = json.optJSONArray("tool_calls") ?: JSONArray()

            for (i in 0 until arr.length()) {
                val item = arr.getJSONObject(i)
                val tool = item.getString("tool")
                val args = item.optJSONObject("arguments") ?: JSONObject()
                val declaredRisk =
                    try {
                        BrainRisk.valueOf(
                            item.optString(
                                "risk",
                                BrainToolRegistry.riskFor(tool).name
                            )
                        )
                    } catch (_: Exception) {
                        BrainToolRegistry.riskFor(tool)
                    }

                // Never allow a backend to downgrade local tool risk.
                val localRisk = BrainToolRegistry.riskFor(tool)
                val effectiveRisk =
                    if (localRisk.ordinal > declaredRisk.ordinal)
                        localRisk
                    else
                        declaredRisk

                calls += BrainToolCall(
                    tool = tool,
                    arguments = args,
                    risk = effectiveRisk,
                    reason = item.optString(
                        "reason",
                        "Remote brain requested this tool."
                    )
                )
            }

            if (calls.size > 8) {
                return Result.failure(
                    IllegalStateException("Backend requested too many tool calls.")
                )
            }

            Result.success(
                BrainPlan(
                    reply = reply,
                    toolCalls = calls,
                    needsConfirmation = calls.any {
                        it.risk != BrainRisk.LOW
                    }
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
