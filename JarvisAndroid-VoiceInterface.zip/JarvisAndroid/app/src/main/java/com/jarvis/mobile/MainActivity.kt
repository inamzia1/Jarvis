package com.jarvis.mobile

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.jarvis.mobile.databinding.ActivityMainBinding
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var binding: ActivityMainBinding
    private lateinit var voice: VoiceController
    private lateinit var executor: PhoneActionExecutor
    private lateinit var contactResolver: ContactResolver
    private lateinit var messagingExecutor: MessagingExecutor
    private lateinit var calendarRepository: CalendarRepository
    private lateinit var reminderScheduler: ReminderScheduler
    private lateinit var mediaControllerEngine: MediaControllerEngine

    private val parser = CommandParser()
    private val messagingParser = MessagingCommandParser()
    private val calendarParser = CalendarCommandParser()
    private val mediaParser = MediaCommandParser()
    private val fileParser = FileCommandParser()
    private val visionParser = VisionCommandParser()
    private var tts: TextToSpeech? = null
    private var pendingMessagingAction: MessagingAction? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        executor = PhoneActionExecutor(this)
        contactResolver = ContactResolver(this)
        messagingExecutor = MessagingExecutor(this, contactResolver)
        calendarRepository = CalendarRepository(this)
        reminderScheduler = ReminderScheduler(this)
        mediaControllerEngine = MediaControllerEngine(this)
        tts = TextToSpeech(this, this)

        voice = VoiceController(
            this,
            onText = {
                binding.commandInput.setText(it)
                binding.orbStateText.text = "PROCESSING"
                handleCommand(it)
            },
            onStatus = {
                binding.systemStatus.text = it.uppercase()
                binding.orbStateText.text = when {
                    it.contains("listen", ignoreCase = true) -> "LISTENING"
                    it.contains("recogn", ignoreCase = true) -> "PROCESSING"
                    else -> "TAP TO SPEAK"
                }
            }
        )

        binding.capabilitiesText.text = """
✓ Voice input
✓ Spoken responses
✓ Launch installed apps
✓ Web search and URLs
✓ Maps hand-off
✓ Camera launch
✓ Wi-Fi settings
✓ Bluetooth settings
✓ Dialer
✓ Direct call with confirmation
✓ Alarm creation
✓ Contact lookup
✓ SMS composition
✓ WhatsApp composition
✓ Contact disambiguation
✓ Notification listener
✓ Local notification intelligence inbox
✓ Priority scoring
✓ App grouping summary
✓ Supported Android quick replies
✓ Calendar day/week briefing
✓ Calendar event preparation
✓ Local JARVIS reminders
✓ Media play/pause
✓ Next / previous track
✓ Media volume control
✓ Mute / unmute
✓ Spotify / YouTube Music launch
✓ Authorized-folder file access
✓ File search / metadata index
✓ Open / share files
✓ Rename with confirmation
✓ Delete with confirmation
✓ Camera capture
✓ Gallery image import
✓ Local image quality inspection
✓ Vision analysis interface
✓ AI brain planner
✓ Multi-step action plans
✓ Approval-aware tool execution
✓ 30-turn conversation memory
✓ Optional remote reasoning backend

EXAMPLES:
• "Text Ali saying I'll call you tonight"
• "SMS +923001234567: Meeting at 4"
• "WhatsApp Hamza saying I'm on my way"

NEXT:
○ Business integrations
○ Automation routines
        """.trimIndent()

        binding.runButton.setOnClickListener {
            handleCommand(binding.commandInput.text.toString())
        }

        binding.micButton.setOnClickListener {
            voice.start()
        }

        binding.brainButton.setOnClickListener {
            startActivity(Intent(this, BrainActivity::class.java))
        }

        binding.visionButton.setOnClickListener {
            startActivity(Intent(this, VisionActivity::class.java))
        }

        binding.filesButton.setOnClickListener {
            startActivity(Intent(this, FilesActivity::class.java))
        }

        binding.mediaButton.setOnClickListener {
            startActivity(Intent(this, MediaActivity::class.java))
        }

        binding.calendarButton.setOnClickListener {
            startActivity(Intent(this, CalendarActivity::class.java))
        }

        binding.notificationInboxButton.setOnClickListener {
            startActivity(Intent(this, NotificationInboxActivity::class.java))
        }

        binding.notificationAccessButton.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
    }

    private fun handleCommand(raw: String) {
        if (raw.isBlank()) {
            respond("Give me a command.")
            return
        }

        val visionCommand = visionParser.parse(raw)
        if (visionCommand != null) {
            handleVisionCommand(visionCommand)
            return
        }

        val fileCommand = fileParser.parse(raw)
        if (fileCommand != null) {
            handleFileCommand(fileCommand)
            return
        }

        val mediaCommand = mediaParser.parse(raw)
        if (mediaCommand != null) {
            handleMediaCommand(mediaCommand)
            return
        }

        val calendarCommand = calendarParser.parse(raw)
        if (calendarCommand != null) {
            handleCalendarCommand(calendarCommand)
            return
        }

        val messaging = messagingParser.parse(raw)
        if (messaging != null) {
            confirmMessagingAction(messaging)
            return
        }

        val action = parser.parse(raw)

        if (action.risk == RiskLevel.HIGH) {
            AlertDialog.Builder(this)
                .setTitle("Confirm JARVIS action")
                .setMessage(describe(action))
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Execute") { _, _ ->
                    respond(executor.execute(action))
                }
                .show()
        } else {
            respond(executor.execute(action))
        }
    }





    private fun handleVisionCommand(command: VisionCommand) {
        when (command) {
            VisionCommand.OpenVision,
            VisionCommand.TakePhoto,
            VisionCommand.ImportImage -> {
                startActivity(Intent(this, VisionActivity::class.java))
                respond("Opening JARVIS vision.")
            }
        }
    }

    private fun handleFileCommand(command: FileCommand) {
        when (command) {
            FileCommand.OpenFileManager -> {
                startActivity(Intent(this, FilesActivity::class.java))
                respond("Opening JARVIS files.")
            }

            is FileCommand.Find -> {
                val manager = FileAccessManager(this)

                if (manager.savedTrees().isEmpty()) {
                    AlertDialog.Builder(this)
                        .setTitle("Folder access required")
                        .setMessage(
                            "Authorize at least one folder in JARVIS Files first. " +
                            "Android only lets JARVIS browse folders you explicitly grant."
                        )
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Open Files") { _, _ ->
                            startActivity(Intent(this, FilesActivity::class.java))
                        }
                        .show()
                    return
                }

                val matches = manager.search(command.query).take(5)

                respond(
                    if (matches.isEmpty()) {
                        "I couldn't find a file matching ${command.query} in your authorized folders."
                    } else {
                        val names = matches.joinToString(", ") { it.name }
                        "I found ${matches.size} matching item${if (matches.size == 1) "" else "s"}: $names."
                    }
                )
            }
        }
    }

    private fun handleMediaCommand(command: MediaCommand) {
        if (
            command in listOf(
                MediaCommand.Play,
                MediaCommand.Pause,
                MediaCommand.Next,
                MediaCommand.Previous,
                MediaCommand.Toggle
            ) &&
            !mediaControllerEngine.hasNotificationAccess()
        ) {
            AlertDialog.Builder(this)
                .setTitle("Media session access required")
                .setMessage(
                    "JARVIS needs notification-listener access to discover " +
                    "active media sessions exposed by playback apps."
                )
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Open settings") { _, _ ->
                    startActivity(
                        Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                    )
                }
                .show()
            return
        }

        respond(mediaControllerEngine.execute(command))
    }

    private fun handleCalendarCommand(command: CalendarCommand) {
        when (command) {
            CalendarCommand.Today -> {
                if (!calendarRepository.hasReadPermission()) {
                    ActivityCompat.requestPermissions(
                        this,
                        arrayOf(Manifest.permission.READ_CALENDAR),
                        41
                    )
                    respond("Calendar access is required. Grant it, then repeat the command.")
                    return
                }

                val events = calendarRepository.today()
                respond(buildBriefing("today", events))
            }

            CalendarCommand.Week -> {
                if (!calendarRepository.hasReadPermission()) {
                    ActivityCompat.requestPermissions(
                        this,
                        arrayOf(Manifest.permission.READ_CALENDAR),
                        41
                    )
                    respond("Calendar access is required. Grant it, then repeat the command.")
                    return
                }

                val events = calendarRepository.nextSevenDays()
                respond(buildBriefing("the next seven days", events))
            }

            is CalendarCommand.CreateEvent -> {
                val whenText = java.text.DateFormat.getDateTimeInstance(
                    java.text.DateFormat.MEDIUM,
                    java.text.DateFormat.SHORT
                ).format(java.util.Date(command.startMillis))

                AlertDialog.Builder(this)
                    .setTitle("Create calendar event?")
                    .setMessage("${command.title}\n$whenText\nDuration: 1 hour")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Open Calendar") { _, _ ->
                        val intent = Intent(android.content.Intent.ACTION_INSERT)
                            .setData(android.provider.CalendarContract.Events.CONTENT_URI)
                            .putExtra(android.provider.CalendarContract.EXTRA_EVENT_BEGIN_TIME, command.startMillis)
                            .putExtra(android.provider.CalendarContract.EXTRA_EVENT_END_TIME, command.endMillis)
                            .putExtra(android.provider.CalendarContract.Events.TITLE, command.title)

                        try {
                            startActivity(intent)
                            respond("Calendar opened with the event prepared for review.")
                        } catch (_: Exception) {
                            respond("No compatible calendar app is available.")
                        }
                    }
                    .show()
            }

            is CalendarCommand.Reminder -> {
                val whenText = java.text.DateFormat.getDateTimeInstance(
                    java.text.DateFormat.MEDIUM,
                    java.text.DateFormat.SHORT
                ).format(java.util.Date(command.triggerAtMillis))

                AlertDialog.Builder(this)
                    .setTitle("Set JARVIS reminder?")
                    .setMessage("${command.text}\n$whenText")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Set reminder") { _, _ ->
                        if (
                            android.os.Build.VERSION.SDK_INT >= 33 &&
                            androidx.core.content.ContextCompat.checkSelfPermission(
                                this,
                                Manifest.permission.POST_NOTIFICATIONS
                            ) != PackageManager.PERMISSION_GRANTED
                        ) {
                            ActivityCompat.requestPermissions(
                                this,
                                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                                42
                            )
                            respond("Notification permission is required for JARVIS reminders.")
                        } else {
                            reminderScheduler.schedule(
                                command.text,
                                command.triggerAtMillis
                            )
                            respond("Reminder scheduled for $whenText.")
                        }
                    }
                    .show()
            }
        }
    }

    private fun buildBriefing(
        range: String,
        events: List<CalendarEvent>
    ): String {
        if (events.isEmpty()) {
            return "Your calendar is clear for $range."
        }

        val formatter = java.text.DateFormat.getTimeInstance(
            java.text.DateFormat.SHORT
        )

        val preview = events.take(5).joinToString(". ") { event ->
            if (event.allDay) {
                "${event.title}, all day"
            } else {
                "${event.title} at ${formatter.format(java.util.Date(event.beginMillis))}"
            }
        }

        val extra =
            if (events.size > 5) " Plus ${events.size - 5} more." else ""

        return "You have ${events.size} event${if (events.size == 1) "" else "s"} for $range. $preview.$extra"
    }

    private fun confirmMessagingAction(action: MessagingAction) {
        val summary = when (action) {
            is MessagingAction.ComposeSms ->
                "Prepare an SMS to ${action.recipient}?\n\n${action.body}"

            is MessagingAction.ComposeWhatsApp ->
                "Prepare a WhatsApp message${action.recipient?.let { " to $it" } ?: ""}?\n\n${action.body}"

            is MessagingAction.ResolveAndComposeSms ->
                "Look up ${action.contactName} and prepare an SMS?\n\n${action.body}"

            is MessagingAction.ResolveAndComposeWhatsApp ->
                "Look up ${action.contactName} and prepare a WhatsApp message?\n\n${action.body}"
        }

        AlertDialog.Builder(this)
            .setTitle("Confirm message")
            .setMessage(summary)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Continue") { _, _ ->
                executeMessaging(action)
            }
            .show()
    }

    private fun executeMessaging(action: MessagingAction) {
        when (val result = messagingExecutor.execute(action)) {
            is MessagingResult.Success ->
                respond(result.message)

            is MessagingResult.Failure ->
                respond(result.message)

            is MessagingResult.NeedsContactPermission -> {
                pendingMessagingAction = action
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.READ_CONTACTS),
                    31
                )
                respond("Contact access is required to resolve ${result.contactName}.")
            }

            is MessagingResult.NeedsDisambiguation ->
                showContactPicker(result)
        }
    }

    private fun showContactPicker(result: MessagingResult.NeedsDisambiguation) {
        val labels = result.matches
            .map { "${it.displayName}\n${it.phoneNumber}" }
            .toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Which contact?")
            .setItems(labels) { _, which ->
                val selected = result.matches[which]

                val finalResult = if (result.app == "sms") {
                    messagingExecutor.composeSms(selected.phoneNumber, result.body)
                } else {
                    messagingExecutor.composeWhatsApp(selected.phoneNumber, result.body)
                }

                when (finalResult) {
                    is MessagingResult.Success -> respond(finalResult.message)
                    is MessagingResult.Failure -> respond(finalResult.message)
                    else -> respond("Unable to complete message preparation.")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (
            requestCode == 31 &&
            grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            pendingMessagingAction?.let {
                pendingMessagingAction = null
                executeMessaging(it)
            }
        }
    }

    private fun describe(action: JarvisAction): String =
        when (action) {
            is JarvisAction.Call -> "Place a phone call to ${action.number}?"
            else -> "Execute this sensitive action?"
        }

    private fun respond(text: String) {
        binding.responseText.text = text
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.UK
            tts?.setPitch(0.85f)
            tts?.setSpeechRate(0.95f)
        }
    }

    override fun onDestroy() {
        voice.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
