package com.jarvis.mobile

import org.json.JSONObject

enum class BrainRisk {
    LOW,
    MEDIUM,
    HIGH
}

data class BrainToolCall(
    val tool: String,
    val arguments: JSONObject,
    val risk: BrainRisk,
    val reason: String
)

data class BrainPlan(
    val reply: String,
    val toolCalls: List<BrainToolCall>,
    val needsConfirmation: Boolean
)

data class BrainTurn(
    val role: String,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

sealed class BrainMode {
    data object Local : BrainMode()
    data class Remote(
        val endpoint: String,
        val bearerToken: String?
    ) : BrainMode()
}
