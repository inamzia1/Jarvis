package com.jarvis.mobile

import android.app.AlertDialog
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.jarvis.mobile.databinding.ActivityBrainSettingsBinding

class BrainSettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityBrainSettingsBinding
    private lateinit var settings: BrainSettings
    private lateinit var memory: BrainMemory

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBrainSettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        settings = BrainSettings(this)
        memory = BrainMemory(this)

        binding.remoteEnabled.isChecked = settings.remoteEnabled()
        binding.endpointInput.setText(settings.currentEndpoint())
        binding.tokenInput.setText(settings.currentToken())

        binding.saveButton.setOnClickListener {
            settings.save(
                binding.remoteEnabled.isChecked,
                binding.endpointInput.text.toString(),
                binding.tokenInput.text.toString()
            )

            AlertDialog.Builder(this)
                .setMessage("AI brain settings saved.")
                .setPositiveButton("OK", null)
                .show()
        }

        binding.clearMemoryButton.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Clear JARVIS memory?")
                .setMessage("This clears the local 30-turn conversation memory.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Clear") { _, _ ->
                    memory.clear()
                }
                .show()
        }
    }
}
