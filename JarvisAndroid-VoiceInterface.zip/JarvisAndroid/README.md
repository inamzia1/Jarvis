# JARVIS Android — Parts 1–8

## Part 8 — AI Brain + Structured Tool Calling

This is the first orchestration layer that sits above all earlier phone modules.

### Local brain
Runs without a network backend.

It can:
- retain recent conversation context
- split multi-step commands such as:
  "open Spotify and then set volume to 60 and then open notifications"
- build structured tool calls
- classify each action by risk
- group a plan before execution
- require approval whenever medium/high-risk tools are present
- fall back safely when language is unsupported

### Remote brain
Brain Settings can point to a user-controlled HTTPS backend.

Android sends:
{
  "input": "...",
  "memory": [...],
  "tools": [...],
  "policy": {
    "require_approval_for_medium": true,
    "require_approval_for_high": true,
    "max_tool_calls": 8
  }
}

Expected backend response:
{
  "reply": "I can do that.",
  "tool_calls": [
    {
      "tool": "open_app",
      "arguments": {"app_name": "Spotify"},
      "risk": "LOW",
      "reason": "User asked to open Spotify."
    }
  ]
}

JARVIS locally re-checks the risk of every tool so a remote model cannot
downgrade a high-risk tool to low risk.

### Available AI tools
- open_app
- web_search
- navigate
- dial
- call
- compose_sms
- compose_whatsapp
- calendar_today
- calendar_week
- set_reminder_minutes
- media
- volume
- find_file
- open_files
- open_vision
- open_notifications

### Approval model
LOW:
- ordinary app launch
- media controls
- searches
- reading authorized information

MEDIUM:
- message preparation
- reminders
- dialer actions

HIGH:
- direct calling
- unknown/unregistered tools

A plan containing any medium/high-risk tool is shown to the user before execution.

### Memory
Local SharedPreferences store up to 30 recent user/assistant turns.

### Security architecture
Provider API secrets should not be compiled into the Android application.
The remote brain is designed to call a backend you control, which can then
call an AI provider server-side.

### OpenAI integration
A server implementation can use the OpenAI Responses API with function calling.
The OpenAI function-calling flow maps naturally to this architecture:

model -> tool call -> local/app tool execution -> tool output -> model response

For production, define tools with strict JSON schemas and keep sensitive
credentials server-side.

## Current complete stack

1. Core phone actions
2. Contacts + messaging
3. Notification intelligence
4. Calendar + reminders
5. Media + audio
6. Files + documents
7. Camera + vision
8. AI brain + tool orchestration

## Next module
Part 9: Business integrations and business memory:
- company profile
- CRM
- leads
- Gmail/business email
- client workflows
- sales pipeline
- quotes/invoices hooks
- combining phone JARVIS with the business JARVIS originally requested


## Part 8.1 — Voice Command Interface
- Voice-first HUD dashboard
- Central JARVIS orb
- Live LISTENING / PROCESSING / READY states
- Recognized speech is immediately routed into the command engine
- Typed command console remains available
- Quick module dashboard for AI Brain, Vision, Files, Media, Calendar and Inbox
