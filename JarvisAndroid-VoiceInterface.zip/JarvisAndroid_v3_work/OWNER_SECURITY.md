# JARVIS v4.1 Owner-Locked Access

## Owner-only controls
JARVIS requires Android strong biometric or device credential authentication.
A successful unlock creates only a short in-memory session (5 minutes). It does not store
your fingerprint, face data, PIN, or password.

Background voice commands are rejected while JARVIS is locked.

## Broad Android access
The app can request normal Android permissions for:
- camera
- microphone
- contacts
- calendar
- notifications
- authorized files/folders
- media controls
- internet / web search
- app launching and Android intents

Android still decides whether each permission or protected action is allowed.

## Camera
Camera access is permission-gated and can be additionally routed through owner authentication.
JARVIS cannot silently bypass Android's camera privacy indicators.

## Online access
The LLM backend can retrieve web information. Provider/API secrets stay on the backend.
A second owner token can be configured server-side with `JARVIS_OWNER_TOKEN`.

## Security boundary
This intentionally does not add root access, hidden accessibility abuse, lock-screen bypasses,
or stealth surveillance. Those would make a compromised assistant far more dangerous.
