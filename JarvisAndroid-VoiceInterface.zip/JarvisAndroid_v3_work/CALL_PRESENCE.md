# JARVIS v4.3 — Call Presence

JARVIS now has an explicit non-impersonating call-presence policy.

Default voice:
"The user is not available right now. Please leave a message and they will get back to you."

The assistant never pretends to be the owner.

Important Android limitation: ordinary Android apps cannot generally answer a WhatsApp or
Instagram VoIP call on behalf of another app and inject synthesized audio into that call.
Those apps would need to expose an official supported integration. JARVIS can still detect
supported call/missed-call notifications and send the configured follow-up reply through
notification actions where available.

For ordinary carrier calls, Android's role/telecom APIs are heavily permission- and
role-controlled and should only be enabled through user-approved system roles.
