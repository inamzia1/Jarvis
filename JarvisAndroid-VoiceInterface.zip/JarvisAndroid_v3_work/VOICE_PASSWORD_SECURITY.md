# JARVIS v4.4 — Wake Password

Desired flow:

1. Owner says the JARVIS wake phrase.
2. JARVIS asks for the configured voice password.
3. Correct password -> short owner session starts.
4. Wrong password -> JARVIS session is immediately locked.
5. The Android device can also be locked with `DevicePolicyManager.lockNow()` only if the
   owner has explicitly enabled JARVIS as a Device Administrator.

The password itself is not stored. JARVIS stores a random salt and a PBKDF2-HMAC-SHA256
verifier (120,000 iterations).

## Important security note

A spoken password can be overheard or replayed from a recording. Therefore the existing
Android biometric/device-credential gate remains the stronger authentication mechanism.
For sensitive operations JARVIS should still request biometric/device credential approval.

JARVIS does not attempt to bypass the Android lock screen, enroll Device Administrator
silently, wipe data, or repeatedly lock the device due to ambient speech.
