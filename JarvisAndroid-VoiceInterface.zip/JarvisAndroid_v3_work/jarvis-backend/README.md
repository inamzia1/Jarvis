# JARVIS Brain Backend

This backend keeps the OpenAI API key outside the Android APK.

## Endpoints

- `GET /health`
- `POST /jarvis/plan`
- `POST /jarvis/finalize`
- `POST /jarvis/vision`

## Run locally

```bash
cp .env.example .env
npm install
OPENAI_API_KEY=... JARVIS_SHARED_TOKEN=... npm start
```

## Deploy

`render.yaml` is included for a simple Render deployment. Set these server-side environment variables:

- `OPENAI_API_KEY`
- `OPENAI_MODEL` (defaults to `gpt-5.6`)
- `JARVIS_SHARED_TOKEN`

After deployment, enter this in the Android app's AI Brain Settings:

Endpoint:
`https://YOUR-SERVER/jarvis/plan`

Bearer token:
the same value as `JARVIS_SHARED_TOKEN`

Enable remote brain and save.


## Free-form LLM mode

The remote brain is now the primary natural-language interpreter.

It can:
- understand ordinary free-form conversation rather than fixed command phrases
- use recent conversation context
- use durable user/business memory
- decide when Android tools are needed
- use OpenAI web search for current information
- plan multiple phone actions
- synthesize Android tool results into a final natural response

"Learning" here means persistent memory and contextual adaptation. The production model
does not retrain its neural weights from each conversation.
