# JARVIS v4.6 Permission Setup

On first launch JARVIS can explain why permissions are needed and then request the
standard Android runtime permissions required by enabled features.

Runtime permission manager:
`JarvisPermissionManager(activity).requestRequiredPermissions(permissionLauncher)`

Special Android access is intentionally not silently enabled. Android requires the owner
to grant Notification Access, Accessibility, Display over other apps, and certain battery
settings from system Settings. Helper methods are included to open each correct screen.

The app remains usable when optional permissions are denied; features depending on a
denied permission should remain disabled until permission is granted.
