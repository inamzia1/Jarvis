# JARVIS Android v3 — Cinematic Assistant

Movie-inspired Android assistant with a futuristic HUD, voice, AI planning,
vision, files, media, notifications, calendar/reminders and a local business command center.

The speech profile is a calm British cinematic AI voice using Android TTS.
It intentionally does not clone or impersonate the actor who voiced JARVIS in the films.

## Highlights
- Cinematic HUD and energy-orb interface
- live partial speech transcript
- final-only command execution
- optional continuous listening while the app is open
- UK English TTS tuning
- AI brain with structured tool plans and confirmation gates
- notifications, calendar, reminders, media, files and vision
- device battery/network/memory status
- local CRM lead pipeline and business tasks
- combined daily briefing

## Android limits
Android sandboxing and permission rules still apply. The app cannot silently
obtain unrestricted control of protected apps, private system storage or other
restricted functions. Sensitive actions remain confirmation-gated.

## Remote AI
For broad conversational intelligence, connect Brain Settings to a backend you
control. Keep AI-provider API secrets on the server, not in the APK.


## Real AI brain upgrade

This package now includes `jarvis-backend/`, a server-side OpenAI Responses API brain.

Flow:

Android voice/text
→ `/jarvis/plan`
→ OpenAI chooses device tools
→ Android approval gate
→ Android executes tools
→ `/jarvis/finalize`
→ OpenAI turns the real tool results into a natural final answer

The API key is never stored in the APK.

The backend also includes `/jarvis/vision` for future semantic image analysis.


## Background voice mode

JARVIS v3.1 adds an explicitly enabled Android foreground microphone service.
After granting microphone permission, tap **ENABLE BACKGROUND JARVIS** once.

While the service is running, a persistent Android notification shows that the
microphone service is active. You can leave the app and say commands such as:

- "Jarvis, play Blinding Lights"
- "Jarvis, play my workout playlist"
- "Jarvis, pause the music"
- "Jarvis, next song"
- "Jarvis, volume 60"
- "Jarvis, open Spotify"
- "Jarvis, system status"

Music searches route to Spotify when installed, with YouTube Music as fallback.

Important Android limitation: this is a foreground voice service, not privileged
system-level hotword hardware. Android/OEM battery management or speech-recognizer
behaviour can stop/restart recognition, and the user-visible microphone notification
is required. Sensitive or complex commands still enter the normal JARVIS approval flow.


## v3.2 — Free-form LLM agent

With Remote Brain enabled, JARVIS no longer depends on exact command phrases.
The LLM is the primary interpreter for normal language, slang, typos, references
to previous turns and multi-step instructions.

It can answer normal questions without a phone tool, use web search for current
information, select Android tools when a real phone action is needed, and remember
stable user/business preferences through a separate long-term memory store.

This is persistent contextual learning, not on-device model weight training.
Android permission and security boundaries still determine which physical actions
can actually be executed.


## v3.3 — Urdu + Hindi

JARVIS now supports:
- English
- Urdu script (اردو)
- Hindi/Devanagari (हिन्दी)
- Roman Urdu
- Roman Hindi
- mixed Urdu-English and Hindi-English conversation

The remote LLM mirrors the user's language naturally. Android speech recognition is
configured for multilingual preference where the device recognizer supports it, and
TTS selects Urdu or Hindi voices when those voices are installed on the phone.

Examples:
- "Jarvis, Atif Aslam ka gaana chalao"
- "Jarvis, kal mera schedule kya hai?"
- "جاروس، آج میرے کیلنڈر میں کیا ہے؟"
- "जार्विस, मेरा अगला गाना चलाओ"


## v3.4
Wake name standardized to **JARVIS**. Added multilingual wake phrase parser, branding concept, and project review (`PROJECT_REVIEW.md`).


## v3.5 — Internet / Google retrieval
JARVIS can detect validated internet connectivity and open Google searches from Android.
For questions requiring fresh information, the remote brain is instructed to use its web-search
capability rather than guessing. This avoids brittle/unsupported scraping of Google result pages.
Examples: "Jarvis, search Google for today's GBP to PKR rate", "what happened in the news today?",
"find restaurants near me", and "look up the latest Android update".


## JARVIS 4.0
UI/security hardening release. Adds HUD design resources, biometric/device-security checks,
HTTPS-only production networking, backend defensive headers, prompt-injection rules, least-privilege
tool policy, and confirmation requirements for high-impact actions.


## v4.1 — Owner-Locked Broad Access
Adds biometric/device-credential lock, short owner session, camera permission path,
secure online capability broker, background-voice lock enforcement, backup hardening,
and optional second owner token for the AI backend.


## v4.2 — Communication Intelligence
Adds priority-notification scoring, an owner-controlled generic notification reply engine
for compatible messaging apps such as WhatsApp/Instagram, missed-call tracking, and a
secure architecture for Gmail through official OAuth/API access.


## v4.3 — Call Presence
Adds a non-impersonating call-presence voice message and policy. JARVIS identifies itself
as an assistant/unavailability response rather than pretending to be the owner.


## v4.4 — Wake Password Security
Adds a salted PBKDF2 voice-password verifier for the JARVIS wake flow. A wrong password
immediately locks the JARVIS owner session. Device locking is available only after the
owner explicitly grants Android Device Administrator force-lock permission.


## v4.5 — Password Management
Adds owner-facing Set Password, Change Password and Remove Password flows. Changing a
password requires the current password and confirmation of the new password.
