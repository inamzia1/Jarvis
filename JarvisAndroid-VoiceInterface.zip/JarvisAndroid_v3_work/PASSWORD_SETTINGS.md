# JARVIS v4.5 — Password Settings

The owner can now:
- set the initial JARVIS password;
- change it by entering the current password first;
- confirm the new password before it is saved;
- remove the JARVIS voice password after entering the current password.

The plaintext password is never stored. `VoicePinGate` continues to store only a salted
PBKDF2-HMAC-SHA256 verifier. Changing/removing the password locks the active JARVIS session.

`PasswordSettingsDialogs(activity).show()` opens the Android password-management UI and
can be wired to the Security/Settings button in the main interface.
