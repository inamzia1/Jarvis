package com.jarvis.mobile

class FileCommandParser {

    fun parse(raw: String): FileCommand? {
        val text = raw.trim()
        val lower = text.lowercase()

        Regex(
            """(?:find|search for|locate)\s+(?:file\s+)?(.+)""",
            RegexOption.IGNORE_CASE
        ).find(text)?.let {
            return FileCommand.Find(it.groupValues[1].trim())
        }

        if (
            lower == "open files" ||
            lower == "open file manager" ||
            lower == "show files"
        ) return FileCommand.OpenFileManager

        return null
    }
}
