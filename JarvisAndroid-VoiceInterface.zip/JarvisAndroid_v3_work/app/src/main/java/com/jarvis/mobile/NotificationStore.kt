package com.jarvis.mobile

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object NotificationStore {
    private const val PREFS = "jarvis_notification_store"
    private const val KEY_RECORDS = "records"
    private const val MAX_RECORDS = 200

    fun save(context: Context, record: NotificationRecord) {
        val records = load(context).toMutableList()
        records.removeAll { it.key == record.key }
        records.add(0, record)

        val trimmed = records.take(MAX_RECORDS)
        persist(context, trimmed)
    }

    fun remove(context: Context, key: String) {
        persist(context, load(context).filterNot { it.key == key })
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .remove(KEY_RECORDS)
            .apply()
    }

    fun load(context: Context): List<NotificationRecord> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_RECORDS, null) ?: return emptyList()

        return try {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    add(
                        NotificationRecord(
                            key = o.getString("key"),
                            packageName = o.getString("packageName"),
                            appName = o.getString("appName"),
                            title = o.optString("title"),
                            text = o.optString("text"),
                            postedAt = o.optLong("postedAt"),
                            priorityScore = o.optInt("priorityScore"),
                            hasQuickReply = o.optBoolean("hasQuickReply")
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun persist(context: Context, records: List<NotificationRecord>) {
        val arr = JSONArray()
        records.forEach { r ->
            arr.put(
                JSONObject().apply {
                    put("key", r.key)
                    put("packageName", r.packageName)
                    put("appName", r.appName)
                    put("title", r.title)
                    put("text", r.text)
                    put("postedAt", r.postedAt)
                    put("priorityScore", r.priorityScore)
                    put("hasQuickReply", r.hasQuickReply)
                }
            )
        }

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_RECORDS, arr.toString())
            .apply()
    }
}
