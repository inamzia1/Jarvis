package com.jarvis.mobile

import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

class JarvisVoiceService : Service() {

    companion object {
        const val CHANNEL = "jarvis_voice"
        const val ACTION_STOP = "com.jarvis.mobile.STOP_VOICE"
        const val ACTION_START = "com.jarvis.mobile.START_VOICE"
        const val EXTRA_COMMAND = "command"

        fun start(context: Context) {
            val i = Intent(context, JarvisVoiceService::class.java).setAction(ACTION_START)
            ContextCompat.startForegroundService(context, i)
        }

        fun stop(context: Context) {
            context.startService(Intent(context, JarvisVoiceService::class.java).setAction(ACTION_STOP))
        }
    }

    private var voice: ServiceVoiceRecognizer? = null
    private lateinit var speech: JarvisSpeechEngine
    private lateinit var executor: BackgroundCommandExecutor

    override fun onCreate() {
        super.onCreate()
        createChannel()
        speech = JarvisSpeechEngine(this)
        executor = BackgroundCommandExecutor(this, speech)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopListening()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(91, notification("Listening for “Jarvis”…"))
        startListening()
        return START_STICKY
    }

    private fun startListening() {
        if (voice != null) return
        voice = ServiceVoiceRecognizer(
            context = this,
            onPhrase = { phrase ->
                val clean = phrase.trim()
                val lower = clean.lowercase()
                val wakeIndex = lower.indexOf("jarvis")
                if (wakeIndex >= 0) {
                    val command = clean.substring(wakeIndex + "jarvis".length)
                        .trim(' ', ',', '.', ':', ';')
                    if (!OwnerSession.isAuthenticated()) {
                        speech.speak("JARVIS is locked. Open the app and authenticate first.")
                    } else if (command.isBlank()) {
                        speech.speak("Yes?")
                    } else {
                        executor.execute(command)
                    }
                }
            },
            onState = { state ->
                val manager = getSystemService(NotificationManager::class.java)
                manager.notify(91, notification(state))
            }
        ).also { it.startLoop() }
    }

    private fun stopListening() {
        voice?.destroy()
        voice = null
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL,
                "JARVIS voice",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Persistent JARVIS wake-listening service"
                setSound(null, null)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, JarvisVoiceService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("JARVIS Voice Online")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(0, "STOP", stop)
            .build()
    }

    override fun onDestroy() {
        stopListening()
        speech.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
