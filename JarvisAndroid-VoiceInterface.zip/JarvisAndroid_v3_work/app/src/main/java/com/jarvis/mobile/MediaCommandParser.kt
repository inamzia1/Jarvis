package com.jarvis.mobile

import java.util.Locale

class MediaCommandParser {

    fun parse(raw: String): MediaCommand? {
        val text = raw.trim()
        val lower = text.lowercase(Locale.getDefault())

        when {
            lower in listOf("play", "play music", "resume", "resume music") ->
                return MediaCommand.Play

            lower in listOf("pause", "pause music", "pause playback") ->
                return MediaCommand.Pause

            lower in listOf("next", "next song", "skip", "skip song") ->
                return MediaCommand.Next

            lower in listOf("previous", "previous song", "go back", "last song") ->
                return MediaCommand.Previous

            lower in listOf("play pause", "toggle playback") ->
                return MediaCommand.Toggle

            lower in listOf("volume up", "increase volume", "louder") ->
                return MediaCommand.VolumeUp

            lower in listOf("volume down", "decrease volume", "quieter") ->
                return MediaCommand.VolumeDown

            lower in listOf("mute", "mute media", "mute music") ->
                return MediaCommand.Mute

            lower in listOf("unmute", "unmute media", "unmute music") ->
                return MediaCommand.Unmute
        }

        Regex("""(?:set\s+)?volume(?:\s+to)?\s+(\d{1,3})\s*%?""",
            RegexOption.IGNORE_CASE
        ).find(text)?.let {
            return MediaCommand.VolumePercent(
                it.groupValues[1].toInt().coerceIn(0, 100)
            )
        }

        Regex("""(?:play|open)\s+(spotify|youtube music|yt music|apple music|soundcloud)""",
            RegexOption.IGNORE_CASE
        ).find(text)?.let {
            return MediaCommand.LaunchMediaApp(it.groupValues[1].trim())
        }

        return null
    }
}
