package com.jarvis.mobile

data class MissedCallEvent(
    val app: String,
    val caller: String,
    val timestamp: Long = System.currentTimeMillis()
)

object MissedCallAssistant {
    private val events = ArrayDeque<MissedCallEvent>()

    @Synchronized fun record(app: String, caller: String) {
        events.addFirst(MissedCallEvent(app, caller))
        while (events.size > 30) events.removeLast()
    }

    @Synchronized fun recent(): List<MissedCallEvent> = events.toList()

    fun suggestedReply(): String =
        "Sorry, I couldn't take your call. Please leave me a message and I'll get back to you."
}
