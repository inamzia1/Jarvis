package com.jarvis.mobile

sealed class MessagingAction {
    data class ComposeSms(
        val recipient: String,
        val body: String
    ) : MessagingAction()

    data class ComposeWhatsApp(
        val recipient: String?,
        val body: String
    ) : MessagingAction()

    data class ResolveAndComposeSms(
        val contactName: String,
        val body: String
    ) : MessagingAction()

    data class ResolveAndComposeWhatsApp(
        val contactName: String,
        val body: String
    ) : MessagingAction()
}
