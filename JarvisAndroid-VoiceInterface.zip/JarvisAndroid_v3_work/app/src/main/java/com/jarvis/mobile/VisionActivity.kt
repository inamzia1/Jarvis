package com.jarvis.mobile

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.jarvis.mobile.databinding.ActivityVisionBinding
import kotlinx.coroutines.launch
import java.io.File

class VisionActivity : AppCompatActivity() {

    private lateinit var binding: ActivityVisionBinding
    private lateinit var inspector: LocalVisionInspector
    private val analyzer: VisionAnalyzer = OfflineVisionAnalyzer()

    private var currentUri: Uri? = null
    private var pendingCameraUri: Uri? = null

    private val requestCameraPermission =
        registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { granted ->
            if (granted) launchCamera()
            else binding.statusText.text = "Camera permission denied."
        }

    private val takePicture =
        registerForActivityResult(
            ActivityResultContracts.TakePicture()
        ) { success ->
            val uri = pendingCameraUri
            if (success && uri != null) {
                loadImage(uri)
            } else {
                binding.statusText.text = "Camera capture cancelled."
            }
        }

    private val pickImage =
        registerForActivityResult(
            ActivityResultContracts.GetContent()
        ) { uri ->
            if (uri != null) loadImage(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityVisionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        inspector = LocalVisionInspector(this)

        binding.cameraButton.setOnClickListener {
            if (
                ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.CAMERA
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                launchCamera()
            } else {
                requestCameraPermission.launch(Manifest.permission.CAMERA)
            }
        }

        binding.importButton.setOnClickListener {
            pickImage.launch("image/*")
        }

        binding.analyzeButton.setOnClickListener {
            val uri = currentUri
            if (uri == null) {
                binding.aiResultText.text = "Select or capture an image first."
                return@setOnClickListener
            }

            val prompt = binding.promptInput.text.toString().trim()
                .ifBlank {
                    "Describe this image and identify useful actions."
                }

            binding.aiResultText.text = "Analyzing..."

            lifecycleScope.launch {
                val result = analyzer.analyze(uri, prompt)
                binding.aiResultText.text =
                    result.getOrElse {
                        it.message ?: "Vision analysis failed."
                    }
            }
        }
    }

    private fun launchCamera() {
        val dir = File(cacheDir, "vision").apply { mkdirs() }
        val file = File(
            dir,
            "capture_${System.currentTimeMillis()}.jpg"
        )

        val uri = FileProvider.getUriForFile(
            this,
            "${packageName}.fileprovider",
            file
        )

        pendingCameraUri = uri
        takePicture.launch(uri)
    }

    private fun loadImage(uri: Uri) {
        currentUri = uri
        binding.imagePreview.setImageURI(uri)
        binding.statusText.text = "Image loaded."

        val result = inspector.inspect(uri)

        if (result.isFailure) {
            binding.metadataText.text =
                result.exceptionOrNull()?.message
                    ?: "Unable to inspect image."
            return
        }

        val image = result.getOrThrow()
        val local = inspector.analyze(image)

        binding.metadataText.text =
            "${image.width} × ${image.height}\n" +
            "${image.orientation}\n" +
            "${image.mimeType}\n" +
            "${formatBytes(image.sizeBytes)}\n" +
            "Average brightness: ${image.averageLuma}/255"

        binding.localAnalysisText.text = buildString {
            append(local.summary)
            if (local.warnings.isNotEmpty()) {
                append("\n\nWarnings:\n")
                local.warnings.forEach {
                    append("• $it\n")
                }
            }
        }

        binding.promptInput.setText(local.suggestedPrompt)
    }

    private fun formatBytes(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024) return String.format("%.1f KB", kb)
        val mb = kb / 1024.0
        return String.format("%.1f MB", mb)
    }
}
