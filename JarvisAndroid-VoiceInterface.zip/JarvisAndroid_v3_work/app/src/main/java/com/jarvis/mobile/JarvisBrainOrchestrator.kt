package com.jarvis.mobile

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class JarvisBrainOrchestrator(
    context: Context
) {
    private val memory = BrainMemory(context)
    private val settings = BrainSettings(context)
    private val longTerm = JarvisLongTermMemory(context)
    private val local = LocalJarvisBrain()
    private val remote = RemoteJarvisBrain()

    suspend fun plan(input: String): BrainPlan =
        withContext(Dispatchers.IO) {
            val turns = memory.load()
            memory.add("user", input)

            val plan = when (val mode = settings.mode()) {
                BrainMode.Local ->
                    local.plan(input, turns)

                is BrainMode.Remote ->
                    remote.plan(
                        mode = mode,
                        input = input,
                        memory = turns,
                        longTermFacts = longTerm.facts()
                    ).getOrElse {
                            BrainPlan(
                                reply =
                                    "Remote reasoning failed, so I used local fallback. " +
                                    (it.message ?: ""),
                                toolCalls =
                                    local.plan(input, turns).toolCalls,
                                needsConfirmation =
                                    local.plan(input, turns).needsConfirmation
                            )
                        }
            }

            memory.add("assistant", plan.reply)
            longTerm.merge(plan.memoryUpdates)
            plan
        }


    suspend fun finalize(
        input: String,
        outputs: List<BrainToolOutput>
    ): String =
        withContext(Dispatchers.IO) {
            when (val mode = settings.mode()) {
                BrainMode.Local ->
                    outputs.joinToString(". ") { it.output }

                is BrainMode.Remote ->
                    remote.finalize(
                        mode = mode,
                        input = input,
                        memory = memory.load(),
                        outputs = outputs,
                        longTermFacts = longTerm.facts()
                    ).getOrElse {
                        outputs.joinToString(". ") { output -> output.output }
                    }
            }
        }

    fun memory(): List<BrainTurn> = memory.load()

    fun longTermFacts(): List<String> = longTerm.facts()

    fun clearLongTermMemory() = longTerm.clear()

    fun clearMemory() = memory.clear()

    fun mode(): BrainMode = settings.mode()
}
