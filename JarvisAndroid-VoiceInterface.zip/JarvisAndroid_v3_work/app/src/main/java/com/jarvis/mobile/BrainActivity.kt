package com.jarvis.mobile

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.jarvis.mobile.databinding.ActivityBrainBinding
import kotlinx.coroutines.launch

class BrainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityBrainBinding
    private lateinit var brain: JarvisBrainOrchestrator
    private lateinit var executor: BrainToolExecutor
    private var activeInput: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBrainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        brain = JarvisBrainOrchestrator(this)
        executor = BrainToolExecutor(this)

        binding.settingsButton.setOnClickListener {
            startActivity(Intent(this, BrainSettingsActivity::class.java))
        }

        binding.sendButton.setOnClickListener {
            val input = binding.commandInput.text.toString().trim()
            if (input.isBlank()) return@setOnClickListener

            binding.commandInput.setText("")
            activeInput = input
            addBubble("YOU", input, false)
            binding.sendButton.isEnabled = false
            binding.modeText.text = "THINKING..."

            lifecycleScope.launch {
                val plan = brain.plan(input)
                binding.sendButton.isEnabled = true
                refreshMode()
                showPlan(plan)
            }
        }

        renderMemory()
    }

    override fun onResume() {
        super.onResume()
        refreshMode()
    }

    private fun renderMemory() {
        binding.chatContainer.removeAllViews()

        brain.memory().takeLast(12).forEach {
            addBubble(
                if (it.role == "user") "YOU" else "JARVIS",
                it.text,
                it.role == "assistant"
            )
        }
    }

    private fun showPlan(plan: BrainPlan) {
        addBubble("JARVIS", plan.reply, true)

        if (plan.toolCalls.isEmpty()) return

        val description = plan.toolCalls.mapIndexed { index, call ->
            "${index + 1}. ${call.tool} [${call.risk}]\n" +
            "${call.arguments}\n${call.reason}"
        }.joinToString("\n\n")

        if (plan.needsConfirmation) {
            AlertDialog.Builder(this)
                .setTitle("JARVIS action plan")
                .setMessage(description)
                .setNegativeButton("Cancel") { _, _ ->
                    addBubble("SYSTEM", "Action plan cancelled.", false)
                }
                .setPositiveButton("Approve") { _, _ ->
                    executePlan(plan)
                }
                .show()
        } else {
            executePlan(plan)
        }
    }

    private fun executePlan(plan: BrainPlan) {
        lifecycleScope.launch {
            val outputs = plan.toolCalls.map { call ->
                BrainToolOutput(
                    tool = call.tool,
                    output = executor.execute(call)
                )
            }

            val finalReply =
                if (outputs.isEmpty()) plan.reply
                else brain.finalize(activeInput, outputs)

            addBubble("JARVIS", finalReply, true)
        }
    }

    private fun refreshMode() {
        binding.modeText.text =
            when (val mode = brain.mode()) {
                BrainMode.Local ->
                    "LOCAL BRAIN · ON-DEVICE PLANNER"

                is BrainMode.Remote ->
                    "REMOTE BRAIN · ${mode.endpoint}"
            }
    }

    private fun addBubble(
        label: String,
        text: String,
        jarvis: Boolean
    ) {
        binding.chatContainer.addView(
            LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(16, 14, 16, 14)
                setBackgroundColor(
                    getColor(
                        if (jarvis)
                            R.color.jarvis_panel
                        else
                            R.color.jarvis_bg
                    )
                )

                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    setMargins(0, 0, 0, 10)
                }

                addView(TextView(this@BrainActivity).apply {
                    this.text = label
                    textSize = 11f
                    setTextColor(getColor(R.color.jarvis_blue))
                })

                addView(TextView(this@BrainActivity).apply {
                    this.text = text
                    textSize = 15f
                    setTextColor(getColor(R.color.jarvis_text))
                })
            }
        )
    }
}
