package com.jarvis.mobile

class VisionCommandParser {

    fun parse(raw: String): VisionCommand? {
        val lower = raw.trim().lowercase()

        return when {
            lower in listOf(
                "open vision",
                "open camera vision",
                "vision mode",
                "jarvis vision"
            ) -> VisionCommand.OpenVision

            lower in listOf(
                "take a photo",
                "take photo",
                "capture image",
                "capture photo"
            ) -> VisionCommand.TakePhoto

            lower in listOf(
                "import image",
                "analyze image",
                "choose image",
                "pick image"
            ) -> VisionCommand.ImportImage

            else -> null
        }
    }
}
