package com.jarvis.mobile

import android.os.Bundle
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.jarvis.mobile.databinding.ActivityBusinessBinding

class BusinessActivity : AppCompatActivity() {
    private lateinit var binding: ActivityBusinessBinding
    private lateinit var store: BusinessStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBusinessBinding.inflate(layoutInflater)
        setContentView(binding.root)
        store = BusinessStore(this)

        binding.addLeadButton.setOnClickListener {
            val name = binding.leadName.text.toString().trim()
            if (name.isNotBlank()) {
                store.addLead(
                    name,
                    binding.companyName.text.toString().trim(),
                    binding.dealValue.text.toString().toDoubleOrNull() ?: 0.0,
                    binding.nextAction.text.toString().trim()
                )
                binding.leadName.setText("")
                binding.companyName.setText("")
                binding.dealValue.setText("")
                binding.nextAction.setText("")
                render()
            }
        }

        binding.addTaskButton.setOnClickListener {
            val title = binding.taskInput.text.toString().trim()
            if (title.isNotBlank()) {
                store.addTask(title)
                binding.taskInput.setText("")
                render()
            }
        }
        render()
    }

    private fun render() {
        binding.businessSummary.text = store.summary()
        binding.leadsContainer.removeAllViews()
        store.leads().sortedByDescending { it.createdAt }.forEach { lead ->
            binding.leadsContainer.addView(TextView(this).apply {
                text = "${lead.name} · ${lead.company}\n${lead.status} · ${"%.0f".format(lead.value)}\n${lead.nextAction}"
                setTextColor(getColor(R.color.jarvis_text))
                setBackgroundResource(R.drawable.jarvis_card)
                setPadding(16, 14, 16, 14)
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(0, 8, 0, 0) }
            })
        }

        binding.tasksContainer.removeAllViews()
        store.tasks().forEach { task ->
            binding.tasksContainer.addView(CheckBox(this).apply {
                text = task.title
                isChecked = task.completed
                setTextColor(getColor(R.color.jarvis_text))
                setOnCheckedChangeListener { _, _ ->
                    store.toggleTask(task.id)
                    render()
                }
            })
        }
    }
}
