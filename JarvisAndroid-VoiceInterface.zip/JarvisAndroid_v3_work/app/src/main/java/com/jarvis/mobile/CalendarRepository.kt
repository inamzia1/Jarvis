package com.jarvis.mobile

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.pm.PackageManager
import android.provider.CalendarContract
import androidx.core.content.ContextCompat
import java.util.Calendar

class CalendarRepository(private val activity: Activity) {

    fun hasReadPermission(): Boolean =
        ContextCompat.checkSelfPermission(
            activity,
            Manifest.permission.READ_CALENDAR
        ) == PackageManager.PERMISSION_GRANTED

    fun eventsBetween(startMillis: Long, endMillis: Long): List<CalendarEvent> {
        if (!hasReadPermission()) return emptyList()

        val builder = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(builder, startMillis)
        ContentUris.appendId(builder, endMillis)

        val projection = arrayOf(
            CalendarContract.Instances.EVENT_ID,
            CalendarContract.Instances.TITLE,
            CalendarContract.Instances.EVENT_LOCATION,
            CalendarContract.Instances.BEGIN,
            CalendarContract.Instances.END,
            CalendarContract.Instances.ALL_DAY
        )

        val events = mutableListOf<CalendarEvent>()

        activity.contentResolver.query(
            builder.build(),
            projection,
            null,
            null,
            "${CalendarContract.Instances.BEGIN} ASC"
        )?.use { cursor ->
            val idIx = cursor.getColumnIndexOrThrow(CalendarContract.Instances.EVENT_ID)
            val titleIx = cursor.getColumnIndexOrThrow(CalendarContract.Instances.TITLE)
            val locationIx = cursor.getColumnIndexOrThrow(CalendarContract.Instances.EVENT_LOCATION)
            val beginIx = cursor.getColumnIndexOrThrow(CalendarContract.Instances.BEGIN)
            val endIx = cursor.getColumnIndexOrThrow(CalendarContract.Instances.END)
            val allDayIx = cursor.getColumnIndexOrThrow(CalendarContract.Instances.ALL_DAY)

            while (cursor.moveToNext()) {
                events += CalendarEvent(
                    eventId = cursor.getLong(idIx),
                    title = cursor.getString(titleIx) ?: "Untitled event",
                    location = cursor.getString(locationIx) ?: "",
                    beginMillis = cursor.getLong(beginIx),
                    endMillis = cursor.getLong(endIx),
                    allDay = cursor.getInt(allDayIx) == 1
                )
            }
        }

        return events
    }

    fun today(): List<CalendarEvent> {
        val now = Calendar.getInstance()

        val start = (now.clone() as Calendar).apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        val end = (start.clone() as Calendar).apply {
            add(Calendar.DAY_OF_MONTH, 1)
        }

        return eventsBetween(start.timeInMillis, end.timeInMillis)
    }

    fun nextSevenDays(): List<CalendarEvent> {
        val start = Calendar.getInstance()
        val end = (start.clone() as Calendar).apply {
            add(Calendar.DAY_OF_MONTH, 7)
        }
        return eventsBetween(start.timeInMillis, end.timeInMillis)
    }
}
