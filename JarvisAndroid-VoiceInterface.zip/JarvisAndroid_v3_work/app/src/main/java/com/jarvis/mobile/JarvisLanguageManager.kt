package com.jarvis.mobile

import java.util.Locale

enum class JarvisLanguage(val tag: String, val displayName: String) {
    AUTO("auto", "Auto"),
    ENGLISH_UK("en-GB", "English"),
    URDU_PAKISTAN("ur-PK", "اردو"),
    HINDI_INDIA("hi-IN", "हिन्दी");

    fun locale(): Locale? = if (this == AUTO) null else Locale.forLanguageTag(tag)
}

object JarvisLanguageManager {
    fun detect(text: String): JarvisLanguage {
        val hasDevanagari = text.any { it.code in 0x0900..0x097F }
        if (hasDevanagari) return JarvisLanguage.HINDI_INDIA

        val hasArabicScript = text.any {
            it.code in 0x0600..0x06FF || it.code in 0x0750..0x077F
        }
        if (hasArabicScript) return JarvisLanguage.URDU_PAKISTAN

        // Roman Urdu/Hindi is intentionally left as AUTO/English recognition:
        // the LLM can understand phrases such as "gaana chalao" or "kal kya hai".
        return JarvisLanguage.AUTO
    }

    fun speechTag(text: String): String {
        return when (detect(text)) {
            JarvisLanguage.URDU_PAKISTAN -> "ur-PK"
            JarvisLanguage.HINDI_INDIA -> "hi-IN"
            else -> "en-GB"
        }
    }
}
