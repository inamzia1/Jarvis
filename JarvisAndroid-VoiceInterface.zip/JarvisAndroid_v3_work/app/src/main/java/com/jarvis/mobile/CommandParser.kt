package com.jarvis.mobile

import java.util.Locale

class CommandParser {
    fun parse(raw: String): JarvisAction {
        val text = raw.trim()
        val lower = text.lowercase(Locale.getDefault())

        if (lower.startsWith("open ")) {
            val name = text.substringAfter("open ").trim()
            if (name.contains(".") && !name.contains(" ")) {
                val url = if (name.startsWith("http")) name else "https://$name"
                return JarvisAction.OpenUrl(url)
            }
            return JarvisAction.OpenApp(name)
        }

        if (lower.startsWith("search for "))
            return JarvisAction.WebSearch(text.substringAfter("search for ").trim())

        if (lower.startsWith("search "))
            return JarvisAction.WebSearch(text.substringAfter("search ").trim())

        if (lower.startsWith("navigate to "))
            return JarvisAction.MapsSearch(text.substringAfter("navigate to ").trim())

        if (lower == "camera" || lower.contains("open camera"))
            return JarvisAction.OpenCamera

        if (lower.contains("wifi settings") || lower.contains("wi-fi settings"))
            return JarvisAction.OpenWifiSettings

        if (lower.contains("bluetooth settings"))
            return JarvisAction.OpenBluetoothSettings

        Regex("""dial\s+([+\d][\d\s-]+)""").find(lower)?.let {
            return JarvisAction.Dial(it.groupValues[1].replace(" ", "").replace("-", ""))
        }

        Regex("""call\s+([+\d][\d\s-]+)""").find(lower)?.let {
            return JarvisAction.Call(it.groupValues[1].replace(" ", "").replace("-", ""))
        }

        Regex("""set alarm(?: for)?\s+(\d{1,2})(?::(\d{2}))?\s*(am|pm)?""").find(lower)?.let {
            var h = it.groupValues[1].toInt()
            val m = it.groupValues[2].ifEmpty { "0" }.toInt()
            val ap = it.groupValues[3]
            if (ap == "pm" && h < 12) h += 12
            if (ap == "am" && h == 12) h = 0
            return JarvisAction.SetAlarm(h, m)
        }

        return JarvisAction.Unknown(text)
    }
}
