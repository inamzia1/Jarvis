package com.jarvis.mobile

import android.app.ActivityManager
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.provider.Settings

data class DeviceStatus(
    val batteryPercent: Int,
    val charging: Boolean,
    val network: String,
    val freeMemoryMb: Long,
    val notificationAccess: Boolean
)

class DeviceStatusProvider(private val context: Context) {
    fun snapshot(): DeviceStatus {
        val battery = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val connectivity = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = connectivity.getNetworkCapabilities(connectivity.activeNetwork)
        val network = when {
            caps == null -> "OFFLINE"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WI-FI"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "MOBILE"
            else -> "ONLINE"
        }
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memory = ActivityManager.MemoryInfo().also(am::getMemoryInfo)
        val enabled = Settings.Secure.getString(
            context.contentResolver, "enabled_notification_listeners"
        ).orEmpty()

        return DeviceStatus(
            batteryPercent = battery.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY).coerceIn(0, 100),
            charging = battery.isCharging,
            network = network,
            freeMemoryMb = memory.availMem / (1024L * 1024L),
            notificationAccess = enabled.contains(context.packageName)
        )
    }

    fun spokenSummary(): String {
        val s = snapshot()
        return "Systems nominal. Battery ${s.batteryPercent} percent" +
            (if (s.charging) " and charging" else "") +
            ". Network ${s.network.lowercase()}. Approximately ${s.freeMemoryMb} megabytes of memory available. " +
            (if (s.notificationAccess) "Notification intelligence is online."
             else "Notification intelligence permission is not enabled.")
    }
}
