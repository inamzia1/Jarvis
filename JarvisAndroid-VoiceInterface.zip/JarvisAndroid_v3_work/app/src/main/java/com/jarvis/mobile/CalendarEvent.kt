package com.jarvis.mobile

data class CalendarEvent(
    val eventId: Long,
    val title: String,
    val location: String,
    val beginMillis: Long,
    val endMillis: Long,
    val allDay: Boolean
)
