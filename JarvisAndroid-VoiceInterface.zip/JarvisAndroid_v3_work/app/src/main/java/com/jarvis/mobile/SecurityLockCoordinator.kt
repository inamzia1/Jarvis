package com.jarvis.mobile

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context

/**
 * Locks JARVIS immediately after a failed voice password.
 *
 * Device locking is intentionally conditional: Android only permits lockNow() when the
 * user has explicitly granted Device Administrator / supported management privileges.
 * JARVIS never bypasses Android security or silently enrolls itself as an administrator.
 */
class SecurityLockCoordinator(private val context: Context) {
    fun lockJarvis() {
        OwnerSession.lock()
    }

    fun lockDeviceIfUserAuthorized(): Boolean {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admin = ComponentName(context, JarvisDeviceAdminReceiver::class.java)
        return if (dpm.isAdminActive(admin)) {
            dpm.lockNow()
            true
        } else false
    }
}
