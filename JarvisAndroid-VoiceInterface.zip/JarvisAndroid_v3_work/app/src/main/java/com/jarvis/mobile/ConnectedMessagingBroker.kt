package com.jarvis.mobile

/**
 * Broker for services that require official APIs/OAuth (for example Gmail).
 *
 * Do not place account passwords, OAuth client secrets, or provider API secrets in the APK.
 * The mobile client should call the owner's authenticated JARVIS backend, which then uses
 * official provider APIs. WhatsApp/Instagram consumer apps are handled only through Android
 * notification actions when those apps expose a Reply action.
 */
object ConnectedMessagingBroker {
    fun genericEmailReply(senderName: String): String =
        "Hi $senderName, thanks for your email. I'm away at the moment, but I've received your message and will reply as soon as I can."
}
