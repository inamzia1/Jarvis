package com.jarvis.mobile

import android.app.Notification

object NotificationPriorityEngine {
    private val urgentTerms = listOf(
        "urgent", "asap", "emergency", "important", "deadline",
        "payment", "invoice", "overdue", "meeting", "call me"
    )

    fun score(notification: Notification, title: String, text: String): Int {
        var score = 10
        val combined = "$title $text".lowercase()

        urgentTerms.forEach { term ->
            if (combined.contains(term)) score += 12
        }

        when (notification.category) {
            Notification.CATEGORY_CALL -> score += 40
            Notification.CATEGORY_MESSAGE -> score += 25
            Notification.CATEGORY_EMAIL -> score += 15
            Notification.CATEGORY_EVENT -> score += 20
            Notification.CATEGORY_ALARM -> score += 30
        }

        if (notification.priority >= Notification.PRIORITY_HIGH) score += 15
        if (hasQuickReply(notification)) score += 10

        return score.coerceIn(0, 100)
    }

    fun hasQuickReply(notification: Notification): Boolean =
        notification.actions?.any { action ->
            action.remoteInputs?.any { !it.isDataOnly } == true
        } == true
}
