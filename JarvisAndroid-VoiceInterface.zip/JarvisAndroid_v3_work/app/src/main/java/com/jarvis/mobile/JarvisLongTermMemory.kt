package com.jarvis.mobile

import android.content.Context
import org.json.JSONArray

class JarvisLongTermMemory(private val context: Context) {
    companion object {
        private const val PREFS = "jarvis_long_term_memory"
        private const val KEY_FACTS = "facts"
        private const val MAX_FACTS = 100
    }

    fun facts(): List<String> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_FACTS, "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length())
                .map { arr.optString(it).trim() }
                .filter { it.isNotBlank() }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun merge(newFacts: List<String>) {
        if (newFacts.isEmpty()) return
        val merged = (facts() + newFacts)
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinctBy { it.lowercase() }
            .takeLast(MAX_FACTS)

        val arr = JSONArray()
        merged.forEach(arr::put)

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_FACTS, arr.toString())
            .apply()
    }

    fun clear() {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .remove(KEY_FACTS)
            .apply()
    }
}
