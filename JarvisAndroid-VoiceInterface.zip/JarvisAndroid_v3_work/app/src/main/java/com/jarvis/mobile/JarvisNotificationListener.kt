package com.jarvis.mobile

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.concurrent.ConcurrentHashMap

class JarvisNotificationListener : NotificationListenerService() {

    companion object {
        private val liveNotifications =
            ConcurrentHashMap<String, StatusBarNotification>()

        fun sendQuickReply(
            key: String,
            replyText: String
        ): Result<Unit> {
            val sbn = liveNotifications[key]
                ?: return Result.failure(
                    IllegalStateException("Notification is no longer active.")
                )

            val action = sbn.notification.actions
                ?.firstOrNull { a ->
                    a.remoteInputs?.any { !it.isDataOnly } == true
                }
                ?: return Result.failure(
                    IllegalStateException("This notification has no quick-reply action.")
                )

            val remoteInputs = action.remoteInputs
                ?.filter { !it.isDataOnly }
                ?.toTypedArray()
                ?: return Result.failure(
                    IllegalStateException("No text reply field is available.")
                )

            return try {
                val intent = Intent()
                val results = Bundle()

                remoteInputs.forEach { input ->
                    results.putCharSequence(input.resultKey, replyText)
                }

                RemoteInput.addResultsToIntent(remoteInputs, intent, results)
                action.actionIntent.send(
                    null,
                    0,
                    intent
                )
                Result.success(Unit)
            } catch (e: PendingIntent.CanceledException) {
                Result.failure(e)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        activeNotifications?.forEach { processNotification(it) }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        processNotification(sbn)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        sbn ?: return
        liveNotifications.remove(sbn.key)
        NotificationStore.remove(applicationContext, sbn.key)
    }

    private fun processNotification(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return

        liveNotifications[sbn.key] = sbn

        val extras = sbn.notification.extras
        val title = extras
            .getCharSequence(Notification.EXTRA_TITLE)
            ?.toString()
            .orEmpty()

        val text = (
            extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
                ?: extras.getCharSequence(Notification.EXTRA_TEXT)
            )?.toString().orEmpty()

        if (title.isBlank() && text.isBlank()) return

        val appName = try {
            val info = packageManager.getApplicationInfo(sbn.packageName, 0)
            packageManager.getApplicationLabel(info).toString()
        } catch (_: Exception) {
            sbn.packageName
        }

        val record = NotificationRecord(
            key = sbn.key,
            packageName = sbn.packageName,
            appName = appName,
            title = title,
            text = text,
            postedAt = sbn.postTime,
            priorityScore = NotificationPriorityEngine.score(
                sbn.notification,
                title,
                text
            ),
            hasQuickReply = NotificationPriorityEngine.hasQuickReply(
                sbn.notification
            )
        )

        NotificationStore.save(applicationContext, record)
    }
}
