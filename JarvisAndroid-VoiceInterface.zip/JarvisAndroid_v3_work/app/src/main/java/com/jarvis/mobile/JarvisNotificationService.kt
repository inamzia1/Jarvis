package com.jarvis.mobile

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class JarvisNotificationService : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val priority = PriorityNotificationEngine.evaluate(sbn)
        if (priority != null) {
            PriorityInboxStore.add(priority)
        }

        // We never silently reply to every message. Auto-reply is opt-in and restricted
        // to the generic away reply selected by the owner.
        val prefs = getSharedPreferences("jarvis_comms", MODE_PRIVATE)
        if (!prefs.getBoolean("generic_auto_reply", false)) return
        if (sbn.notification.category != Notification.CATEGORY_MESSAGE) return

        val allowed = prefs.getStringSet("auto_reply_packages", emptySet()) ?: emptySet()
        if (sbn.packageName !in allowed) return

        val generic = prefs.getString(
            "generic_reply",
            "I'm unavailable right now. I'll get back to you as soon as I can."
        ) ?: return

        replyThroughNotification(sbn.notification, generic)
    }

    private fun replyThroughNotification(notification: Notification, message: String): Boolean {
        for (action in notification.actions ?: emptyArray()) {
            val inputs = action.remoteInputs ?: continue
            if (inputs.isEmpty()) continue
            val intent = Intent()
            val bundle = Bundle()
            inputs.forEach { bundle.putCharSequence(it.resultKey, message) }
            RemoteInput.addResultsToIntent(inputs, intent, bundle)
            try {
                action.actionIntent.send(this, 0, intent)
                return true
            } catch (_: PendingIntent.CanceledException) {
            }
        }
        return false
    }
}

object PriorityInboxStore {
    private val items = ArrayDeque<PriorityNotice>()

    @Synchronized fun add(item: PriorityNotice) {
        items.addFirst(item)
        while (items.size > 50) items.removeLast()
    }

    @Synchronized fun latest(): List<PriorityNotice> = items.toList()
}
