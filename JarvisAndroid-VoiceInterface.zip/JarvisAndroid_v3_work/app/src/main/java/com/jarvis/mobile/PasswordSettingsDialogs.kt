package com.jarvis.mobile

import android.app.Activity
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import androidx.appcompat.app.AlertDialog

class PasswordSettingsDialogs(private val activity: Activity) {
    private val settings = JarvisPasswordSettings(activity)

    fun show() {
        val options = if (VoicePinGate(activity).hasPin())
            arrayOf("Change JARVIS password", "Remove JARVIS password", "Cancel")
        else
            arrayOf("Set JARVIS password", "Cancel")

        AlertDialog.Builder(activity)
            .setTitle("JARVIS Security")
            .setItems(options) { _, which ->
                if (!VoicePinGate(activity).hasPin()) {
                    if (which == 0) showSet()
                } else {
                    when (which) {
                        0 -> showChange()
                        1 -> showRemove()
                    }
                }
            }.show()
    }

    private fun passwordField(hint: String) = EditText(activity).apply {
        this.hint = hint
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    }

    private fun form(vararg fields: EditText) = LinearLayout(activity).apply {
        orientation = LinearLayout.VERTICAL
        val pad = (20 * resources.displayMetrics.density).toInt()
        setPadding(pad, pad / 2, pad, 0)
        fields.forEach { addView(it) }
    }

    private fun showSet() {
        val p1 = passwordField("New password")
        val p2 = passwordField("Confirm password")
        AlertDialog.Builder(activity)
            .setTitle("Set JARVIS password")
            .setView(form(p1, p2))
            .setPositiveButton("Set") { _, _ ->
                showResult(settings.createPassword(p1.text.toString(), p2.text.toString()))
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun showChange() {
        val old = passwordField("Current password")
        val p1 = passwordField("New password")
        val p2 = passwordField("Confirm new password")
        AlertDialog.Builder(activity)
            .setTitle("Change JARVIS password")
            .setView(form(old, p1, p2))
            .setPositiveButton("Change") { _, _ ->
                showResult(settings.changePassword(
                    old.text.toString(), p1.text.toString(), p2.text.toString()
                ))
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun showRemove() {
        val old = passwordField("Current password")
        AlertDialog.Builder(activity)
            .setTitle("Remove JARVIS password?")
            .setMessage("Wake-word password protection will be disabled.")
            .setView(old)
            .setPositiveButton("Remove") { _, _ ->
                showResult(settings.removePassword(old.text.toString()))
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun showResult(result: PasswordChangeResult) {
        val message = when (result) {
            PasswordChangeResult.Success -> "Security setting updated successfully."
            is PasswordChangeResult.Error -> result.message
        }
        AlertDialog.Builder(activity).setMessage(message).setPositiveButton("OK", null).show()
    }
}
