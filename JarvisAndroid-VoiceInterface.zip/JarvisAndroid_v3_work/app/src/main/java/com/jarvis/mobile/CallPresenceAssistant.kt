package com.jarvis.mobile

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

class CallPresenceAssistant(private val context: Context) {
    private var tts: TextToSpeech? = null

    fun defaultMessage(): String =
        "The user is not available right now. Please leave a message and they will get back to you."

    fun speakUnavailableMessage(onReady: (() -> Unit)? = null) {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
                tts?.speak(defaultMessage(), TextToSpeech.QUEUE_FLUSH, null, "jarvis_unavailable")
                onReady?.invoke()
            }
        }
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
