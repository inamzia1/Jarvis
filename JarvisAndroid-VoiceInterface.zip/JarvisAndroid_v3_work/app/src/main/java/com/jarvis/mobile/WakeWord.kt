package com.jarvis.mobile

object WakeWord {
    const val WORD = "jarvis"

    private val patterns = listOf(
        Regex("""\bjarvis\b""", RegexOption.IGNORE_CASE),
        Regex("""\bhey\s+jarvis\b""", RegexOption.IGNORE_CASE),
        Regex("""\bok(?:ay)?\s+jarvis\b""", RegexOption.IGNORE_CASE),
        Regex("""جاروس|जार्विस""")
    )

    fun isWakePhrase(text: String): Boolean =
        patterns.any { it.containsMatchIn(text.trim()) }

    fun stripWakePhrase(text: String): String {
        var result = text.trim()
        patterns.forEach { result = result.replace(it, "") }
        return result.trim().trimStart(',', '.', ':', '-', ' ')
    }
}
