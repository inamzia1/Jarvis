package com.jarvis.mobile

import android.content.Context

class CommunicationPolicy(context: Context) {
    private val prefs = context.getSharedPreferences("jarvis_comms", Context.MODE_PRIVATE)

    fun enableGenericReplies(enabled: Boolean) =
        prefs.edit().putBoolean("generic_auto_reply", enabled).apply()

    fun setGenericReply(text: String) =
        prefs.edit().putString("generic_reply", text.take(300)).apply()

    fun allowPackage(packageName: String, allowed: Boolean) {
        val set = (prefs.getStringSet("auto_reply_packages", emptySet()) ?: emptySet()).toMutableSet()
        if (allowed) set.add(packageName) else set.remove(packageName)
        prefs.edit().putStringSet("auto_reply_packages", set).apply()
    }

    fun configureCommonMessagingApps() {
        // Only works where the installed app exposes Android notification reply actions.
        prefs.edit().putStringSet(
            "auto_reply_packages",
            setOf(
                "com.whatsapp",
                "com.whatsapp.w4b",
                "com.instagram.android"
            )
        ).apply()
    }
}
