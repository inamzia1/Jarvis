package com.jarvis.mobile

import android.app.admin.DeviceAdminReceiver

class JarvisDeviceAdminReceiver : DeviceAdminReceiver()
