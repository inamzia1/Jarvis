package com.jarvis.mobile

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.util.Locale

class JarvisSpeechEngine(context: Context) : TextToSpeech.OnInitListener {
    private val tts = TextToSpeech(context, this)
    private var ready = false

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        tts.language = Locale.UK
        val ukVoice = tts.voices
            ?.filter { it.locale.language == "en" && it.locale.country == "GB" }
            ?.sortedWith(compareBy<Voice>({ it.isNetworkConnectionRequired }, { -it.quality }))
            ?.firstOrNull()
        if (ukVoice != null) tts.voice = ukVoice
        tts.setPitch(0.88f)
        tts.setSpeechRate(0.92f)
        ready = true
    }

    fun speak(text: String) {
        val requestedLocale = java.util.Locale.forLanguageTag(
            JarvisLanguageManager.speechTag(text)
        )
        if (tts.isLanguageAvailable(requestedLocale) >= android.speech.tts.TextToSpeech.LANG_AVAILABLE) {
            tts.language = requestedLocale
        }
        if (ready && text.isNotBlank()) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-response")
        }
    }

    fun shutdown() {
        tts.stop()
        tts.shutdown()
    }
}
