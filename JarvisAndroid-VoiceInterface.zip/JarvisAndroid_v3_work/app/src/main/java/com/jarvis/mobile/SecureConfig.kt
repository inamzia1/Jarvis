package com.jarvis.mobile

import android.content.Context

object SecureConfig {
    private const val PREFS = "jarvis_secure_settings"

    fun setBackendUrl(context: Context, url: String) {
        require(url.startsWith("https://") || url.startsWith("http://10.") ||
                url.startsWith("http://192.168.") || url.startsWith("http://localhost"))
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString("backend_url", url.trimEnd('/')).apply()
    }

    fun getBackendUrl(context: Context): String? =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString("backend_url", null)

    // API keys deliberately do not belong here or in the APK.
    // Keep provider secrets on the JARVIS backend only.
}
