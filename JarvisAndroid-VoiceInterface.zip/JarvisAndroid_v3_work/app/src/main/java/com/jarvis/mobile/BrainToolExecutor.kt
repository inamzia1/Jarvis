package com.jarvis.mobile

import android.app.Activity
import android.content.Intent

class BrainToolExecutor(
    private val activity: Activity
) {
    private val phone = PhoneActionExecutor(activity)
    private val contacts = ContactResolver(activity)
    private val messaging = MessagingExecutor(activity, contacts)
    private val calendar = CalendarRepository(activity)
    private val reminders = ReminderScheduler(activity)
    private val media = MediaControllerEngine(activity)

    fun execute(call: BrainToolCall): String {
        return when (call.tool) {
            "open_app" ->
                phone.execute(
                    JarvisAction.OpenApp(
                        call.arguments.optString("app_name")
                    )
                )

            "web_search" ->
                phone.execute(
                    JarvisAction.WebSearch(
                        call.arguments.optString("query")
                    )
                )

            "navigate" ->
                phone.execute(
                    JarvisAction.MapsSearch(
                        call.arguments.optString("destination")
                    )
                )

            "dial" ->
                phone.execute(
                    JarvisAction.Dial(
                        call.arguments.optString("number")
                    )
                )

            "call" ->
                phone.execute(
                    JarvisAction.Call(
                        call.arguments.optString("number")
                    )
                )

            "compose_sms" -> {
                val recipient = call.arguments.optString("recipient")
                val body = call.arguments.optString("body")
                val action =
                    if (recipient.matches(Regex("""[+\d][\d\s()\-]{5,}""")))
                        MessagingAction.ComposeSms(recipient, body)
                    else
                        MessagingAction.ResolveAndComposeSms(recipient, body)

                formatMessaging(messaging.execute(action))
            }

            "compose_whatsapp" -> {
                val recipient = call.arguments.optString("recipient")
                val body = call.arguments.optString("body")
                val action =
                    if (recipient.matches(Regex("""[+\d][\d\s()\-]{5,}""")))
                        MessagingAction.ComposeWhatsApp(recipient, body)
                    else
                        MessagingAction.ResolveAndComposeWhatsApp(recipient, body)

                formatMessaging(messaging.execute(action))
            }

            "calendar_today" -> {
                if (!calendar.hasReadPermission()) {
                    "Calendar permission is required."
                } else {
                    summarizeEvents(calendar.today(), "today")
                }
            }

            "calendar_week" -> {
                if (!calendar.hasReadPermission()) {
                    "Calendar permission is required."
                } else {
                    summarizeEvents(
                        calendar.nextSevenDays(),
                        "the next seven days"
                    )
                }
            }

            "set_reminder_minutes" -> {
                val minutes = call.arguments.optLong("minutes", 0)
                val text = call.arguments.optString("text")
                if (minutes <= 0 || text.isBlank()) {
                    "Invalid reminder request."
                } else {
                    reminders.schedule(
                        text,
                        System.currentTimeMillis() + minutes * 60_000L
                    )
                    "Reminder scheduled in $minutes minutes."
                }
            }

            "media" -> {
                val command = when (
                    call.arguments.optString("command").lowercase()
                ) {
                    "play" -> MediaCommand.Play
                    "pause" -> MediaCommand.Pause
                    "next" -> MediaCommand.Next
                    "previous" -> MediaCommand.Previous
                    else -> MediaCommand.Toggle
                }
                media.execute(command)
            }

            "volume" ->
                media.execute(
                    MediaCommand.VolumePercent(
                        call.arguments.optInt("percent", 50)
                            .coerceIn(0, 100)
                    )
                )

            "find_file" -> {
                val manager = FileAccessManager(activity)
                val matches =
                    manager.search(
                        call.arguments.optString("query")
                    ).take(5)

                if (matches.isEmpty()) {
                    "No matching authorized files found."
                } else {
                    "Found: ${matches.joinToString(", ") { it.name }}"
                }
            }

            "open_files" -> {
                activity.startActivity(
                    Intent(activity, FilesActivity::class.java)
                )
                "Opened JARVIS files."
            }

            "open_vision" -> {
                activity.startActivity(
                    Intent(activity, VisionActivity::class.java)
                )
                "Opened JARVIS vision."
            }

            "open_notifications" -> {
                activity.startActivity(
                    Intent(
                        activity,
                        NotificationInboxActivity::class.java
                    )
                )
                "Opened notification intelligence."
            }

            else ->
                "Unknown tool: ${call.tool}"
        }
    }

    private fun formatMessaging(
        result: MessagingResult
    ): String =
        when (result) {
            is MessagingResult.Success -> result.message
            is MessagingResult.Failure -> result.message
            is MessagingResult.NeedsContactPermission ->
                "Contact permission is required to resolve ${result.contactName}."
            is MessagingResult.NeedsDisambiguation ->
                "Multiple contacts matched. Open the messaging module to choose one."
        }

    private fun summarizeEvents(
        events: List<CalendarEvent>,
        range: String
    ): String {
        if (events.isEmpty()) {
            return "Calendar is clear for $range."
        }

        val names = events.take(5).joinToString(", ") {
            it.title
        }

        return "${events.size} event${if (events.size == 1) "" else "s"} for $range: $names."
    }
}
