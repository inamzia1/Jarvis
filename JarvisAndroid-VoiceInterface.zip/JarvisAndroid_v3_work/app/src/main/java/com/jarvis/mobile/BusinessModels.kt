package com.jarvis.mobile

data class BusinessLead(
    val id: Long,
    val name: String,
    val company: String,
    val status: String,
    val value: Double,
    val nextAction: String,
    val createdAt: Long
)

data class BusinessTask(
    val id: Long,
    val title: String,
    val completed: Boolean
)

data class BusinessSnapshot(
    val activeLeads: Int,
    val pipelineValue: Double,
    val openTasks: Int
)
