package com.jarvis.mobile

import android.content.Context
import android.content.Intent

data class AppLaunchResult(val success: Boolean, val message: String)

class AppLauncher(private val context: Context) {
    private val aliases = mapOf(
        "spotify" to "com.spotify.music",
        "youtube" to "com.google.android.youtube",
        "youtube music" to "com.google.android.apps.youtube.music",
        "whatsapp" to "com.whatsapp",
        "instagram" to "com.instagram.android",
        "gmail" to "com.google.android.gm",
        "chrome" to "com.android.chrome",
        "maps" to "com.google.android.apps.maps",
        "google maps" to "com.google.android.apps.maps"
    )

    fun launch(name: String): AppLaunchResult {
        val requested = name.trim()
        val packageName = aliases[requested.lowercase()]
            ?: findInstalledPackage(requested)

        if (packageName == null) {
            return AppLaunchResult(false, "I couldn't find $requested installed.")
        }

        val intent = context.packageManager.getLaunchIntentForPackage(packageName)
            ?: return AppLaunchResult(false, "I couldn't open $requested.")

        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            AppLaunchResult(true, "Opening $requested.")
        } catch (_: Exception) {
            AppLaunchResult(false, "Android couldn't open $requested.")
        }
    }

    private fun findInstalledPackage(name: String): String? {
        val pm = context.packageManager
        return pm.getInstalledApplications(0).firstOrNull { app ->
            pm.getApplicationLabel(app).toString().equals(name, ignoreCase = true)
        }?.packageName
    }
}
