package com.jarvis.mobile

import android.app.Activity
import androidx.appcompat.app.AlertDialog

object FirstRunPermissionDialog {
    fun show(activity: Activity, onRequestRuntimePermissions: () -> Unit) {
        val prefs = activity.getSharedPreferences("jarvis_first_run", Activity.MODE_PRIVATE)
        if (prefs.getBoolean("permission_intro_seen", false)) return

        AlertDialog.Builder(activity)
            .setTitle("Set up JARVIS permissions")
            .setMessage(
                "JARVIS needs permission for features you choose to use, such as microphone, " +
                "camera, contacts, calls, notifications and location. Android will show its own " +
                "permission prompts. You can deny anything and enable it later in Settings.\n\n" +
                "Some powerful features—notification access, accessibility, display-over-apps " +
                "and battery exemptions—must be enabled separately in Android Settings."
            )
            .setPositiveButton("Continue") { _, _ ->
                prefs.edit().putBoolean("permission_intro_seen", true).apply()
                onRequestRuntimePermissions()
            }
            .setNegativeButton("Not now") { _, _ ->
                prefs.edit().putBoolean("permission_intro_seen", true).apply()
            }
            .show()
    }
}
