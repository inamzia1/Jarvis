package com.jarvis.mobile

import android.app.AlertDialog
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.jarvis.mobile.databinding.ActivityNotificationInboxBinding
import java.text.DateFormat
import java.util.Date

class NotificationInboxActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNotificationInboxBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNotificationInboxBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.clearButton.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Clear local notification history?")
                .setMessage("This only clears JARVIS's local inbox.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Clear") { _, _ ->
                    NotificationStore.clear(this)
                    render()
                }
                .show()
        }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        val records = NotificationStore.load(this)
            .sortedWith(
                compareByDescending<NotificationRecord> { it.priorityScore }
                    .thenByDescending { it.postedAt }
            )

        binding.inboxContainer.removeAllViews()

        val high = records.count { it.priorityScore >= 60 }
        val replyable = records.count { it.hasQuickReply }
        val apps = records.map { it.appName }.distinct().size

        binding.summaryText.text =
            "${records.size} active items · $high high priority · " +
            "$replyable replyable · $apps apps"

        if (records.isEmpty()) {
            binding.inboxContainer.addView(TextView(this).apply {
                text = "No captured notifications yet. Enable notification access, then new notifications will appear here."
                setTextColor(getColor(R.color.jarvis_muted))
                setPadding(12, 24, 12, 24)
            })
            return
        }

        records.forEach { record ->
            binding.inboxContainer.addView(createCard(record))
        }
    }

    private fun createCard(record: NotificationRecord): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 16)
            setBackgroundColor(getColor(R.color.jarvis_panel))

            val params = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            params.setMargins(0, 0, 0, 12)
            layoutParams = params

            addView(TextView(this@NotificationInboxActivity).apply {
                text = "${record.appName} · PRIORITY ${record.priorityScore}/100"
                setTextColor(getColor(R.color.jarvis_blue))
                textSize = 12f
            })

            addView(TextView(this@NotificationInboxActivity).apply {
                text = record.title.ifBlank { "Notification" }
                setTextColor(getColor(R.color.jarvis_text))
                textSize = 17f
                setTypeface(typeface, Typeface.BOLD)
                setPadding(0, 6, 0, 4)
            })

            addView(TextView(this@NotificationInboxActivity).apply {
                text = record.text
                setTextColor(getColor(R.color.jarvis_text))
                textSize = 14f
            })

            addView(TextView(this@NotificationInboxActivity).apply {
                text = DateFormat.getDateTimeInstance(
                    DateFormat.SHORT,
                    DateFormat.SHORT
                ).format(Date(record.postedAt))
                setTextColor(getColor(R.color.jarvis_muted))
                textSize = 11f
                setPadding(0, 8, 0, 0)
            })

            if (record.hasQuickReply) {
                addView(Button(this@NotificationInboxActivity).apply {
                    text = "PREPARE QUICK REPLY"
                    setOnClickListener {
                        showReplyDialog(record)
                    }
                })
            }
        }
    }

    private fun showReplyDialog(record: NotificationRecord) {
        val input = EditText(this).apply {
            hint = "Reply..."
            inputType = InputType.TYPE_CLASS_TEXT or
                InputType.TYPE_TEXT_FLAG_CAP_SENTENCES or
                InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 2
            setPadding(32, 16, 32, 16)
        }

        AlertDialog.Builder(this)
            .setTitle("Reply to ${record.title.ifBlank { record.appName }}")
            .setMessage("JARVIS will use this notification's supported Android quick-reply action.")
            .setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Review") { _, _ ->
                val text = input.text.toString().trim()
                if (text.isNotEmpty()) confirmSend(record, text)
            }
            .show()
    }

    private fun confirmSend(
        record: NotificationRecord,
        reply: String
    ) {
        AlertDialog.Builder(this)
            .setTitle("Confirm reply")
            .setMessage("$reply\n\nSend through ${record.appName}?")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Send") { _, _ ->
                val result = JarvisNotificationListener.sendQuickReply(
                    record.key,
                    reply
                )

                AlertDialog.Builder(this)
                    .setTitle(if (result.isSuccess) "Sent" else "Unable to send")
                    .setMessage(
                        if (result.isSuccess)
                            "Reply sent through the notification's quick-reply action."
                        else
                            result.exceptionOrNull()?.message
                                ?: "The notification may no longer be active."
                    )
                    .setPositiveButton("OK", null)
                    .show()
            }
            .show()
    }
}
