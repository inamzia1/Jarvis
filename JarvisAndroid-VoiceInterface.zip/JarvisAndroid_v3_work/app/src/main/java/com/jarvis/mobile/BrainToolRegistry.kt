package com.jarvis.mobile

import org.json.JSONArray
import org.json.JSONObject

object BrainToolRegistry {

    data class ToolSpec(
        val name: String,
        val description: String,
        val risk: BrainRisk,
        val argumentHints: Map<String, String>
    )

    val tools = listOf(
        ToolSpec(
            "open_app",
            "Open an installed Android app by human-readable name.",
            BrainRisk.LOW,
            mapOf("app_name" to "string")
        ),
        ToolSpec(
            "web_search",
            "Open a web search for a query.",
            BrainRisk.LOW,
            mapOf("query" to "string")
        ),
        ToolSpec(
            "navigate",
            "Open maps/navigation for a destination.",
            BrainRisk.LOW,
            mapOf("destination" to "string")
        ),
        ToolSpec(
            "dial",
            "Open the dialer with a phone number.",
            BrainRisk.MEDIUM,
            mapOf("number" to "string")
        ),
        ToolSpec(
            "call",
            "Place a phone call after approval.",
            BrainRisk.HIGH,
            mapOf("number" to "string")
        ),
        ToolSpec(
            "compose_sms",
            "Prepare an SMS for review.",
            BrainRisk.MEDIUM,
            mapOf("recipient" to "string", "body" to "string")
        ),
        ToolSpec(
            "compose_whatsapp",
            "Prepare a WhatsApp message for review.",
            BrainRisk.MEDIUM,
            mapOf("recipient" to "string", "body" to "string")
        ),
        ToolSpec(
            "calendar_today",
            "Read today's authorized calendar events.",
            BrainRisk.LOW,
            emptyMap()
        ),
        ToolSpec(
            "calendar_week",
            "Read the next seven days of authorized calendar events.",
            BrainRisk.LOW,
            emptyMap()
        ),
        ToolSpec(
            "set_reminder_minutes",
            "Create a local reminder a number of minutes from now.",
            BrainRisk.MEDIUM,
            mapOf("minutes" to "integer", "text" to "string")
        ),
        ToolSpec(
            "media",
            "Control active media playback.",
            BrainRisk.LOW,
            mapOf("command" to "play|pause|next|previous|toggle")
        ),
        ToolSpec(
            "volume",
            "Set music/media volume percent.",
            BrainRisk.LOW,
            mapOf("percent" to "integer 0-100")
        ),
        ToolSpec(
            "find_file",
            "Search file names in folders explicitly authorized by the user.",
            BrainRisk.LOW,
            mapOf("query" to "string")
        ),
        ToolSpec(
            "open_files",
            "Open JARVIS file manager.",
            BrainRisk.LOW,
            emptyMap()
        ),
        ToolSpec(
            "open_vision",
            "Open the JARVIS camera/vision screen.",
            BrainRisk.LOW,
            emptyMap()
        ),
        ToolSpec(
            "open_notifications",
            "Open the JARVIS notification intelligence inbox.",
            BrainRisk.LOW,
            emptyMap()
        )
    )

    fun asJson(): JSONArray {
        val arr = JSONArray()
        tools.forEach { spec ->
            arr.put(
                JSONObject().apply {
                    put("name", spec.name)
                    put("description", spec.description)
                    put("risk", spec.risk.name)
                    put(
                        "arguments",
                        JSONObject().apply {
                            spec.argumentHints.forEach { (k, v) ->
                                put(k, v)
                            }
                        }
                    )
                }
            )
        }
        return arr
    }

    fun riskFor(tool: String): BrainRisk =
        tools.firstOrNull { it.name == tool }?.risk ?: BrainRisk.HIGH
}
