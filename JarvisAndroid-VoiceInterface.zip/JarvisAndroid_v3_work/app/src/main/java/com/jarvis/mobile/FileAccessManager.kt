package com.jarvis.mobile

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import android.webkit.MimeTypeMap

class FileAccessManager(private val activity: Activity) {

    companion object {
        private const val PREFS = "jarvis_file_access"
        private const val KEY_TREES = "tree_uris"
    }

    fun savedTrees(): List<Uri> {
        val set = activity.getSharedPreferences(PREFS, Activity.MODE_PRIVATE)
            .getStringSet(KEY_TREES, emptySet())
            .orEmpty()
        return set.mapNotNull {
            try { Uri.parse(it) } catch (_: Exception) { null }
        }
    }

    fun rememberTree(uri: Uri) {
        val prefs = activity.getSharedPreferences(PREFS, Activity.MODE_PRIVATE)
        val set = prefs.getStringSet(KEY_TREES, emptySet()).orEmpty().toMutableSet()
        set += uri.toString()
        prefs.edit().putStringSet(KEY_TREES, set).apply()
    }

    fun forgetTree(uri: Uri) {
        val prefs = activity.getSharedPreferences(PREFS, Activity.MODE_PRIVATE)
        val set = prefs.getStringSet(KEY_TREES, emptySet()).orEmpty().toMutableSet()
        set -= uri.toString()
        prefs.edit().putStringSet(KEY_TREES, set).apply()
    }

    fun indexAll(maxItems: Int = 1000): List<JarvisFile> {
        val out = mutableListOf<JarvisFile>()
        for (tree in savedTrees()) {
            scanTree(tree, out, maxItems)
            if (out.size >= maxItems) break
        }
        return out
    }

    fun search(query: String, maxItems: Int = 1000): List<JarvisFile> {
        val q = query.lowercase()
        return indexAll(maxItems).filter {
            it.name.lowercase().contains(q)
        }
    }

    private fun scanTree(
        treeUri: Uri,
        out: MutableList<JarvisFile>,
        maxItems: Int
    ) {
        val rootId = try {
            DocumentsContract.getTreeDocumentId(treeUri)
        } catch (_: Exception) {
            return
        }

        scanChildren(treeUri, rootId, out, maxItems)
    }

    private fun scanChildren(
        treeUri: Uri,
        parentDocumentId: String,
        out: MutableList<JarvisFile>,
        maxItems: Int
    ) {
        if (out.size >= maxItems) return

        val childrenUri =
            DocumentsContract.buildChildDocumentsUriUsingTree(
                treeUri,
                parentDocumentId
            )

        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED
        )

        activity.contentResolver.query(
            childrenUri,
            projection,
            null,
            null,
            null
        )?.use { cursor ->
            val idIx = cursor.getColumnIndexOrThrow(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID
            )
            val nameIx = cursor.getColumnIndexOrThrow(
                DocumentsContract.Document.COLUMN_DISPLAY_NAME
            )
            val mimeIx = cursor.getColumnIndexOrThrow(
                DocumentsContract.Document.COLUMN_MIME_TYPE
            )
            val sizeIx = cursor.getColumnIndexOrThrow(
                DocumentsContract.Document.COLUMN_SIZE
            )
            val modifiedIx = cursor.getColumnIndexOrThrow(
                DocumentsContract.Document.COLUMN_LAST_MODIFIED
            )

            while (cursor.moveToNext() && out.size < maxItems) {
                val id = cursor.getString(idIx)
                val name = cursor.getString(nameIx) ?: "Unnamed"
                val mime = cursor.getString(mimeIx)
                    ?: "application/octet-stream"
                val size =
                    if (cursor.isNull(sizeIx)) 0L else cursor.getLong(sizeIx)
                val modified =
                    if (cursor.isNull(modifiedIx)) 0L else cursor.getLong(modifiedIx)

                val uri = DocumentsContract.buildDocumentUriUsingTree(
                    treeUri,
                    id
                )

                val isDir =
                    mime == DocumentsContract.Document.MIME_TYPE_DIR

                out += JarvisFile(
                    uri = uri,
                    name = name,
                    mimeType = mime,
                    sizeBytes = size,
                    modifiedAt = modified,
                    isDirectory = isDir
                )

                if (isDir) {
                    scanChildren(treeUri, id, out, maxItems)
                }
            }
        }
    }

    fun open(file: JarvisFile): String {
        if (file.isDirectory) return "Folders are managed inside JARVIS."

        return try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(file.uri, file.mimeType)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            activity.startActivity(intent)
            "Opening ${file.name}."
        } catch (_: Exception) {
            "No compatible app could open ${file.name}."
        }
    }

    fun share(file: JarvisFile): String {
        if (file.isDirectory) return "Folders cannot be shared this way."

        return try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = file.mimeType
                putExtra(Intent.EXTRA_STREAM, file.uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            activity.startActivity(
                Intent.createChooser(intent, "Share ${file.name}")
            )
            "Share sheet opened for ${file.name}."
        } catch (_: Exception) {
            "Unable to share ${file.name}."
        }
    }

    fun rename(file: JarvisFile, newName: String): Result<Uri> {
        return try {
            val renamed = DocumentsContract.renameDocument(
                activity.contentResolver,
                file.uri,
                newName
            ) ?: file.uri
            Result.success(renamed)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun delete(file: JarvisFile): Result<Unit> {
        return try {
            val ok = DocumentsContract.deleteDocument(
                activity.contentResolver,
                file.uri
            )
            if (ok) Result.success(Unit)
            else Result.failure(IllegalStateException("Provider refused delete."))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun createFolder(parentTree: Uri, folderName: String): Result<Uri> {
        return try {
            val rootId = DocumentsContract.getTreeDocumentId(parentTree)
            val rootDoc = DocumentsContract.buildDocumentUriUsingTree(
                parentTree,
                rootId
            )

            val created = DocumentsContract.createDocument(
                activity.contentResolver,
                rootDoc,
                DocumentsContract.Document.MIME_TYPE_DIR,
                folderName
            ) ?: return Result.failure(
                IllegalStateException("Provider refused folder creation.")
            )

            Result.success(created)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun guessMime(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton()
            .getMimeTypeFromExtension(ext)
            ?: "application/octet-stream"
    }
}
