package com.jarvis.mobile

import android.content.Context
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Voice PIN gate for the JARVIS wake flow.
 *
 * The PIN itself is never stored. Only a PBKDF2-derived verifier and random salt are saved.
 * This is an assistant authorization layer, not a replacement for Android's lock screen.
 */
class VoicePinGate(context: Context) {
    private val prefs = context.getSharedPreferences("jarvis_voice_pin", Context.MODE_PRIVATE)

    fun hasPin(): Boolean = prefs.contains("hash") && prefs.contains("salt")

    fun setPin(pin: String) {
        require(pin.length >= 4) { "Voice PIN must be at least 4 characters." }
        val salt = ByteArray(24).also { SecureRandom().nextBytes(it) }
        val hash = derive(pin.toCharArray(), salt)
        prefs.edit()
            .putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("hash", Base64.encodeToString(hash, Base64.NO_WRAP))
            .apply()
    }


    fun changePin(currentPin: String, newPin: String): Boolean {
        if (!verify(currentPin)) return false
        setPin(newPin)
        return true
    }

    fun removePin(currentPin: String): Boolean {
        if (!verify(currentPin)) return false
        prefs.edit().remove("salt").remove("hash").remove("failed_attempts").apply()
        return true
    }

    fun verify(candidate: String): Boolean {
        val saltText = prefs.getString("salt", null) ?: return false
        val hashText = prefs.getString("hash", null) ?: return false
        val salt = Base64.decode(saltText, Base64.NO_WRAP)
        val expected = Base64.decode(hashText, Base64.NO_WRAP)
        val actual = derive(candidate.toCharArray(), salt)
        return MessageDigest.isEqual(expected, actual)
    }

    private fun derive(chars: CharArray, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(chars, salt, 120_000, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(spec).encoded
    }
}
