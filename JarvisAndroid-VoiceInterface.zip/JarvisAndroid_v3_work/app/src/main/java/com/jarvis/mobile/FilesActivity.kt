package com.jarvis.mobile

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.jarvis.mobile.databinding.ActivityFilesBinding
import java.text.DateFormat
import java.util.Date

class FilesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFilesBinding
    private lateinit var manager: FileAccessManager

    private val openTree = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        uri ?: return@registerForActivityResult

        try {
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (_: SecurityException) {
            try {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {}
        }

        manager.rememberTree(uri)
        refreshAccess()
        render(manager.indexAll().take(100))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFilesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        manager = FileAccessManager(this)

        binding.addFolderButton.setOnClickListener {
            openTree.launch(null)
        }

        binding.searchButton.setOnClickListener {
            val query = binding.searchInput.text.toString().trim()
            val results =
                if (query.isBlank()) manager.indexAll().take(100)
                else manager.search(query).take(100)

            render(results)
        }

        refreshAccess()
        render(manager.indexAll().take(100))
    }

    private fun refreshAccess() {
        val count = manager.savedTrees().size
        binding.accessSummary.text =
            if (count == 0)
                "No folders authorized. JARVIS cannot browse storage yet."
            else
                "$count authorized folder${if (count == 1) "" else "s"}."
    }

    private fun render(files: List<JarvisFile>) {
        binding.filesContainer.removeAllViews()
        binding.resultSummary.text =
            "${files.size} item${if (files.size == 1) "" else "s"} shown."

        if (files.isEmpty()) {
            binding.filesContainer.addView(TextView(this).apply {
                text = "No matching files."
                setTextColor(getColor(R.color.jarvis_muted))
                setPadding(12, 20, 12, 20)
            })
            return
        }

        files.forEach { file ->
            binding.filesContainer.addView(createFileCard(file))
        }
    }

    private fun createFileCard(file: JarvisFile): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 16)
            setBackgroundColor(getColor(R.color.jarvis_panel))

            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, 0, 12)
            }

            addView(TextView(this@FilesActivity).apply {
                text = file.name
                textSize = 16f
                setTextColor(getColor(R.color.jarvis_text))
            })

            addView(TextView(this@FilesActivity).apply {
                val type = if (file.isDirectory) "Folder" else file.mimeType
                val size =
                    if (file.isDirectory) ""
                    else " · ${formatBytes(file.sizeBytes)}"

                val modified =
                    if (file.modifiedAt > 0)
                        " · ${DateFormat.getDateTimeInstance(
                            DateFormat.SHORT,
                            DateFormat.SHORT
                        ).format(Date(file.modifiedAt))}"
                    else ""

                text = "$type$size$modified"
                setTextColor(getColor(R.color.jarvis_muted))
                textSize = 11f
            })

            val actions = LinearLayout(this@FilesActivity).apply {
                orientation = LinearLayout.HORIZONTAL
            }

            if (!file.isDirectory) {
                actions.addView(Button(this@FilesActivity).apply {
                    text = "OPEN"
                    setOnClickListener {
                        toastDialog(manager.open(file))
                    }
                })

                actions.addView(Button(this@FilesActivity).apply {
                    text = "SHARE"
                    setOnClickListener {
                        toastDialog(manager.share(file))
                    }
                })
            }

            actions.addView(Button(this@FilesActivity).apply {
                text = "RENAME"
                setOnClickListener {
                    renameDialog(file)
                }
            })

            actions.addView(Button(this@FilesActivity).apply {
                text = "DELETE"
                setOnClickListener {
                    deleteDialog(file)
                }
            })

            addView(actions)
        }
    }

    private fun renameDialog(file: JarvisFile) {
        val input = EditText(this).apply {
            setText(file.name)
            setSelection(text.length)
            inputType = InputType.TYPE_CLASS_TEXT
        }

        AlertDialog.Builder(this)
            .setTitle("Rename ${file.name}?")
            .setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Rename") { _, _ ->
                val newName = input.text.toString().trim()
                if (newName.isBlank()) return@setPositiveButton

                val result = manager.rename(file, newName)

                AlertDialog.Builder(this)
                    .setTitle(if (result.isSuccess) "Renamed" else "Unable to rename")
                    .setMessage(
                        if (result.isSuccess)
                            "Renamed to $newName."
                        else
                            result.exceptionOrNull()?.message
                                ?: "The document provider rejected the rename."
                    )
                    .setPositiveButton("OK") { _, _ ->
                        render(manager.indexAll().take(100))
                    }
                    .show()
            }
            .show()
    }

    private fun deleteDialog(file: JarvisFile) {
        AlertDialog.Builder(this)
            .setTitle("Delete ${file.name}?")
            .setMessage(
                "This asks the document provider to permanently delete the selected item."
            )
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ ->
                val result = manager.delete(file)

                AlertDialog.Builder(this)
                    .setTitle(if (result.isSuccess) "Deleted" else "Unable to delete")
                    .setMessage(
                        if (result.isSuccess)
                            "${file.name} was deleted."
                        else
                            result.exceptionOrNull()?.message
                                ?: "The provider rejected the delete."
                    )
                    .setPositiveButton("OK") { _, _ ->
                        render(manager.indexAll().take(100))
                    }
                    .show()
            }
            .show()
    }

    private fun toastDialog(message: String) {
        AlertDialog.Builder(this)
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun formatBytes(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024) return String.format("%.1f KB", kb)
        val mb = kb / 1024.0
        if (mb < 1024) return String.format("%.1f MB", mb)
        val gb = mb / 1024.0
        return String.format("%.1f GB", gb)
    }
}
