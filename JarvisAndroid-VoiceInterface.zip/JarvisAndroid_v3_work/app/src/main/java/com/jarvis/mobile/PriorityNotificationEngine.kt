package com.jarvis.mobile

import android.app.Notification
import android.service.notification.StatusBarNotification

data class PriorityNotice(
    val packageName: String,
    val sender: String,
    val text: String,
    val score: Int,
    val reason: String
)

object PriorityNotificationEngine {
    private val urgentWords = listOf(
        "urgent", "emergency", "asap", "important", "hospital", "accident",
        "deadline", "payment", "overdue", "help", "call me", "immediately",
        "ضروری", "فوری", "ایمرجنسی", "مدد",
        "तुरंत", "ज़रूरी", "आपातकाल"
    )

    fun evaluate(sbn: StatusBarNotification): PriorityNotice? {
        val n = sbn.notification
        val extras = n.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val all = "$title $text".lowercase()

        var score = 0
        val reasons = mutableListOf<String>()
        if (urgentWords.any { all.contains(it) }) {
            score += 55
            reasons += "urgent wording"
        }
        if (n.category == Notification.CATEGORY_CALL) {
            score += 35
            reasons += "call"
        }
        if (n.category == Notification.CATEGORY_MESSAGE) {
            score += 15
            reasons += "message"
        }
        if (n.priority >= Notification.PRIORITY_HIGH) {
            score += 15
            reasons += "high app priority"
        }

        return if (score >= 40)
            PriorityNotice(sbn.packageName, title, text, score.coerceAtMost(100), reasons.joinToString())
        else null
    }
}
