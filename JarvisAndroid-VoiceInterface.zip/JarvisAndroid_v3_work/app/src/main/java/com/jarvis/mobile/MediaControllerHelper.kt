package com.jarvis.mobile

import android.content.ComponentName
import android.content.Context
import android.media.AudioManager
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.provider.Settings

class MediaControllerHelper(private val context: Context) {
    private val audio =
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val sessions =
        context.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager

    private fun listenerComponent() =
        ComponentName(context, JarvisNotificationListener::class.java)

    private fun hasNotificationAccess(): Boolean {
        val enabled = Settings.Secure.getString(
            context.contentResolver,
            "enabled_notification_listeners"
        ) ?: return false
        return enabled.contains(context.packageName)
    }

    private fun controller(): MediaController? {
        if (!hasNotificationAccess()) return null
        return try {
            val active = sessions.getActiveSessions(listenerComponent())
            active.firstOrNull {
                val state = it.playbackState?.state
                state == PlaybackState.STATE_PLAYING ||
                    state == PlaybackState.STATE_BUFFERING
            } ?: active.firstOrNull()
        } catch (_: SecurityException) {
            null
        }
    }

    fun playPause(): String {
        val c = controller()
            ?: return "No active media session found. Notification access may be required."
        val state = c.playbackState?.state
        return if (state == PlaybackState.STATE_PLAYING ||
            state == PlaybackState.STATE_BUFFERING) {
            c.transportControls.pause()
            "Playback paused."
        } else {
            c.transportControls.play()
            "Playback resumed."
        }
    }

    fun next(): String {
        val c = controller() ?: return "No active media session found."
        c.transportControls.skipToNext()
        return "Playing the next track."
    }

    fun previous(): String {
        val c = controller() ?: return "No active media session found."
        c.transportControls.skipToPrevious()
        return "Playing the previous track."
    }

    fun setVolumePercent(percent: Int): String {
        val safe = percent.coerceIn(0, 100)
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val target = ((safe / 100.0) * max).toInt().coerceIn(0, max)
        return try {
            audio.setStreamVolume(
                AudioManager.STREAM_MUSIC,
                target,
                AudioManager.FLAG_SHOW_UI
            )
            "Media volume set to $safe percent."
        } catch (_: SecurityException) {
            "Android blocked direct volume control on this device."
        }
    }
}
