package com.jarvis.mobile

data class NotificationRecord(
    val key: String,
    val packageName: String,
    val appName: String,
    val title: String,
    val text: String,
    val postedAt: Long,
    val priorityScore: Int,
    val hasQuickReply: Boolean
)
