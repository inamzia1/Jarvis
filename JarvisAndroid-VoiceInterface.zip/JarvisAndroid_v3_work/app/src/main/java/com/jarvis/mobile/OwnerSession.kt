package com.jarvis.mobile

object OwnerSession {
    private var authenticatedAt: Long = 0L
    private const val SESSION_MS = 5 * 60 * 1000L

    fun markAuthenticated() {
        authenticatedAt = System.currentTimeMillis()
    }

    fun isAuthenticated(): Boolean =
        authenticatedAt > 0 &&
            System.currentTimeMillis() - authenticatedAt <= SESSION_MS

    fun lock() {
        authenticatedAt = 0L
    }
}
