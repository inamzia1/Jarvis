package com.jarvis.mobile

import android.content.Context

/**
 * Owner-controlled call presence policy.
 *
 * This does NOT impersonate the owner. The only automated spoken content is an explicit
 * assistant disclosure/unavailability message.
 *
 * Third-party VoIP apps such as WhatsApp/Instagram do not provide a general Android API
 * that lets another app silently answer their calls and inject arbitrary synthesized audio.
 * JARVIS therefore uses supported notification/missed-call paths and can provide this
 * message wherever a future/official integration exposes a lawful call-answering hook.
 */
class CallHandlingPolicy(context: Context) {
    private val prefs = context.getSharedPreferences("jarvis_calls", Context.MODE_PRIVATE)

    fun setEnabled(enabled: Boolean) =
        prefs.edit().putBoolean("unavailable_voice_enabled", enabled).apply()

    fun isEnabled(): Boolean =
        prefs.getBoolean("unavailable_voice_enabled", false)

    fun setMessage(message: String) =
        prefs.edit().putString("unavailable_voice_message", message.take(240)).apply()

    fun message(): String =
        prefs.getString(
            "unavailable_voice_message",
            "The user is not available right now. Please leave a message and they will get back to you."
        )!!
}
