package com.jarvis.mobile

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.jarvis.mobile.databinding.ActivityCalendarBinding
import java.text.DateFormat
import java.util.Date

class CalendarActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCalendarBinding
    private lateinit var repository: CalendarRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCalendarBinding.inflate(layoutInflater)
        setContentView(binding.root)

        repository = CalendarRepository(this)

        binding.permissionButton.setOnClickListener {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.READ_CALENDAR),
                41
            )
        }

        binding.todayButton.setOnClickListener {
            render(repository.today(), "today")
        }

        binding.weekButton.setOnClickListener {
            render(repository.nextSevenDays(), "the next 7 days")
        }

        if (repository.hasReadPermission()) {
            render(repository.today(), "today")
        }
    }

    private fun render(events: List<CalendarEvent>, range: String) {
        binding.eventsContainer.removeAllViews()

        binding.briefingText.text =
            if (events.isEmpty())
                "You have no calendar events for $range."
            else
                "You have ${events.size} calendar event${if (events.size == 1) "" else "s"} for $range."

        events.forEach { event ->
            binding.eventsContainer.addView(
                LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(18, 16, 18, 16)
                    setBackgroundColor(getColor(R.color.jarvis_panel))

                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply {
                        setMargins(0, 0, 0, 12)
                    }

                    addView(TextView(this@CalendarActivity).apply {
                        text = event.title
                        textSize = 17f
                        setTextColor(getColor(R.color.jarvis_text))
                    })

                    addView(TextView(this@CalendarActivity).apply {
                        text =
                            if (event.allDay) "All day"
                            else DateFormat.getDateTimeInstance(
                                DateFormat.MEDIUM,
                                DateFormat.SHORT
                            ).format(Date(event.beginMillis))
                        setTextColor(getColor(R.color.jarvis_blue))
                    })

                    if (event.location.isNotBlank()) {
                        addView(TextView(this@CalendarActivity).apply {
                            text = event.location
                            setTextColor(getColor(R.color.jarvis_muted))
                        })
                    }
                }
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (
            requestCode == 41 &&
            grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            render(repository.today(), "today")
        }
    }
}
