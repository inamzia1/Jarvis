package com.jarvis.mobile

import java.util.Locale

class MessagingCommandParser {

    fun parse(raw: String): MessagingAction? {
        val text = raw.trim()
        val lower = text.lowercase(Locale.getDefault())

        Regex("""(?:text|sms|message)\s+(.+?)\s+(?:saying|that|:)\s*(.+)""",
            RegexOption.IGNORE_CASE
        ).find(text)?.let {
            val recipient = it.groupValues[1].trim()
            val body = it.groupValues[2].trim()

            return if (looksLikePhoneNumber(recipient)) {
                MessagingAction.ComposeSms(recipient, body)
            } else {
                MessagingAction.ResolveAndComposeSms(recipient, body)
            }
        }

        Regex("""whatsapp\s+(.+?)\s+(?:saying|that|:)\s*(.+)""",
            RegexOption.IGNORE_CASE
        ).find(text)?.let {
            val recipient = it.groupValues[1].trim()
            val body = it.groupValues[2].trim()

            return if (looksLikePhoneNumber(recipient)) {
                MessagingAction.ComposeWhatsApp(recipient, body)
            } else {
                MessagingAction.ResolveAndComposeWhatsApp(recipient, body)
            }
        }

        if (lower.startsWith("whatsapp ")) {
            val body = text.substringAfter("whatsapp ").trim()
            if (body.isNotBlank()) {
                return MessagingAction.ComposeWhatsApp(null, body)
            }
        }

        return null
    }

    private fun looksLikePhoneNumber(value: String): Boolean =
        value.matches(Regex("""[+\d][\d\s()\-]{5,}"""))
}
