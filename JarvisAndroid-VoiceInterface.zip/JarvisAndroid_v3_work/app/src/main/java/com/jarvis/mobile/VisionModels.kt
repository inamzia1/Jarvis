package com.jarvis.mobile

import android.net.Uri

data class VisionImage(
    val uri: Uri,
    val width: Int,
    val height: Int,
    val sizeBytes: Long,
    val mimeType: String,
    val averageLuma: Int,
    val orientation: String
)

data class VisionAnalysis(
    val summary: String,
    val warnings: List<String>,
    val suggestedPrompt: String
)

sealed class VisionCommand {
    data object OpenVision : VisionCommand()
    data object TakePhoto : VisionCommand()
    data object ImportImage : VisionCommand()
}
