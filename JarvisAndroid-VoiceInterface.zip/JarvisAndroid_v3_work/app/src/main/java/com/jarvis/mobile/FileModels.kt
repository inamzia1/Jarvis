package com.jarvis.mobile

import android.net.Uri

data class JarvisFile(
    val uri: Uri,
    val name: String,
    val mimeType: String,
    val sizeBytes: Long,
    val modifiedAt: Long,
    val isDirectory: Boolean
)

sealed class FileCommand {
    data class Find(val query: String) : FileCommand()
    data object OpenFileManager : FileCommand()
}
