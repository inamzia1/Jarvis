package com.jarvis.mobile

import android.app.Activity

class RoutineEngine(private val activity: Activity) {
    private val calendar = CalendarRepository(activity)
    private val business = BusinessStore(activity)
    private val device = DeviceStatusProvider(activity)

    fun dailyBriefing(): String {
        val parts = mutableListOf("Good day.")
        parts += device.spokenSummary()
        if (calendar.hasReadPermission()) {
            val events = calendar.today()
            parts += if (events.isEmpty()) "Your calendar is clear today."
                     else "You have ${events.size} calendar event${if (events.size == 1) "" else "s"} today."
        }
        parts += business.summary()
        return parts.joinToString(" ")
    }
}
