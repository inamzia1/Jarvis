package com.jarvis.mobile

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

sealed class CalendarCommand {
    data object Today : CalendarCommand()
    data object Week : CalendarCommand()
    data class CreateEvent(
        val title: String,
        val startMillis: Long,
        val endMillis: Long
    ) : CalendarCommand()
    data class Reminder(
        val text: String,
        val triggerAtMillis: Long
    ) : CalendarCommand()
}

class CalendarCommandParser {

    fun parse(raw: String): CalendarCommand? {
        val text = raw.trim()
        val lower = text.lowercase(Locale.getDefault())

        if (
            lower == "what's on today" ||
            lower == "whats on today" ||
            lower.contains("today's schedule") ||
            lower.contains("todays schedule") ||
            lower == "calendar today"
        ) return CalendarCommand.Today

        if (
            lower.contains("this week's schedule") ||
            lower.contains("this weeks schedule") ||
            lower == "calendar week"
        ) return CalendarCommand.Week

        parseReminder(text)?.let { return it }
        parseCreateEvent(text)?.let { return it }

        return null
    }

    private fun parseCreateEvent(text: String): CalendarCommand.CreateEvent? {
        val regex = Regex(
            """(?:schedule|create|add)\s+(?:a\s+)?(?:meeting|event)?\s*(.*?)\s+(?:tomorrow|today)\s+(?:at\s+)?(\d{1,2})(?::(\d{2}))?\s*(am|pm)?""",
            RegexOption.IGNORE_CASE
        )

        val match = regex.find(text) ?: return null
        val title = match.groupValues[1].trim().ifBlank { "JARVIS event" }

        val dayWord = if (text.lowercase().contains("tomorrow")) "tomorrow" else "today"
        val hourRaw = match.groupValues[2].toInt()
        val minute = match.groupValues[3].ifEmpty { "0" }.toInt()
        val amPm = match.groupValues[4].lowercase()

        var hour = hourRaw
        if (amPm == "pm" && hour < 12) hour += 12
        if (amPm == "am" && hour == 12) hour = 0

        val start = Calendar.getInstance().apply {
            if (dayWord == "tomorrow") add(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        val end = (start.clone() as Calendar).apply {
            add(Calendar.HOUR_OF_DAY, 1)
        }

        return CalendarCommand.CreateEvent(
            title,
            start.timeInMillis,
            end.timeInMillis
        )
    }

    private fun parseReminder(text: String): CalendarCommand.Reminder? {
        val inMinutes = Regex(
            """remind me in (\d+)\s+minutes?\s+(?:to\s+)?(.+)""",
            RegexOption.IGNORE_CASE
        ).find(text)

        if (inMinutes != null) {
            val mins = inMinutes.groupValues[1].toLong()
            val body = inMinutes.groupValues[2].trim()
            return CalendarCommand.Reminder(
                body,
                System.currentTimeMillis() + mins * 60_000L
            )
        }

        val atTime = Regex(
            """remind me (?:today|tomorrow)?\s*(?:at\s+)(\d{1,2})(?::(\d{2}))?\s*(am|pm)?\s+(?:to\s+)?(.+)""",
            RegexOption.IGNORE_CASE
        ).find(text)

        if (atTime != null) {
            var hour = atTime.groupValues[1].toInt()
            val minute = atTime.groupValues[2].ifEmpty { "0" }.toInt()
            val amPm = atTime.groupValues[3].lowercase()
            val body = atTime.groupValues[4].trim()

            if (amPm == "pm" && hour < 12) hour += 12
            if (amPm == "am" && hour == 12) hour = 0

            val cal = Calendar.getInstance().apply {
                if (text.lowercase().contains("tomorrow")) add(Calendar.DAY_OF_MONTH, 1)
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                if (!text.lowercase().contains("tomorrow") && timeInMillis <= System.currentTimeMillis()) {
                    add(Calendar.DAY_OF_MONTH, 1)
                }
            }

            return CalendarCommand.Reminder(body, cal.timeInMillis)
        }

        return null
    }
}
