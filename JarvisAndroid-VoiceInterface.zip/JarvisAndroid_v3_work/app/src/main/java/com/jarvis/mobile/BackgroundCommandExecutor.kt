package com.jarvis.mobile

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

class BackgroundCommandExecutor(
    private val context: Context,
    private val speech: JarvisSpeechEngine
) {
    private val media = MediaControllerHelper(context)

    fun execute(raw: String) {
        val command = raw.trim()
        val lower = command.lowercase()

        when {
            lower.startsWith("play ") -> {
                val query = command.substringAfter("play ").trim()
                playRequestedMusic(query)
            }

            lower in listOf("pause", "pause music", "pause the music") -> {
                speech.speak(media.playPause())
            }

            lower in listOf("resume", "resume music", "continue music", "continue the music") -> {
                speech.speak(media.playPause())
            }

            lower in listOf("next", "next song", "next track") -> {
                speech.speak(media.next())
            }

            lower in listOf("previous", "previous song", "previous track") -> {
                speech.speak(media.previous())
            }

            lower.startsWith("volume ") || lower.contains("volume to ") -> {
                val number = Regex("""\d{1,3}""").find(lower)?.value?.toIntOrNull()
                if (number != null) speech.speak(media.setVolumePercent(number))
                else speech.speak("Tell me the volume percentage.")
            }

            lower.startsWith("open ") -> {
                val app = command.substringAfter("open ").trim()
                val launcher = AppLauncher(context)
                val result = launcher.launch(app)
                speech.speak(result.message)
            }

            lower.contains("system status") || lower.contains("device status") -> {
                speech.speak(DeviceStatusProvider(context).spokenSummary())
            }

            else -> {
                // Open the full assistant with the command pre-filled so complex requests
                // can enter the AI/tool approval flow rather than silently executing.
                val intent = Intent(context, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    putExtra(JarvisVoiceService.EXTRA_COMMAND, command)
                }
                context.startActivity(intent)
                speech.speak("Opening the full assistant for that request.")
            }
        }
    }

    private fun playRequestedMusic(query: String) {
        if (query.isBlank()) {
            speech.speak("What would you like me to play?")
            return
        }

        // Try Spotify search first if installed. Spotify handles the actual stream,
        // account and licensing.
        val spotify = context.packageManager.getLaunchIntentForPackage("com.spotify.music")
        if (spotify != null) {
            val uri = Uri.parse("spotify:search:${Uri.encode(query)}")
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                setPackage("com.spotify.music")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                context.startActivity(intent)
                speech.speak("Searching Spotify for $query.")
                return
            } catch (_: Exception) {}
        }

        // Fallback to YouTube Music web/app routing.
        val url = "https://music.youtube.com/search?q=${Uri.encode(query)}"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
            speech.speak("Searching YouTube Music for $query.")
        } catch (_: Exception) {
            speech.speak("I couldn't open a music provider.")
        }
    }
}
