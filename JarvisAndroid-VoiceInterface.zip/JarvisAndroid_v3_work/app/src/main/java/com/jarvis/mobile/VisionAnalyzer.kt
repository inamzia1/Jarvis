package com.jarvis.mobile

import android.net.Uri

interface VisionAnalyzer {
    suspend fun analyze(
        imageUri: Uri,
        userPrompt: String
    ): Result<String>
}

/**
 * Placeholder intentionally kept network-free.
 *
 * Part 8 will provide the real AI reasoning/tool-calling backend and can
 * implement this interface without changing camera/gallery code.
 */
class OfflineVisionAnalyzer : VisionAnalyzer {
    override suspend fun analyze(
        imageUri: Uri,
        userPrompt: String
    ): Result<String> {
        return Result.success(
            "Deep semantic vision is not connected yet. " +
            "The image is prepared and the analysis interface is ready for Part 8."
        )
    }
}
