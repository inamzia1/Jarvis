package com.jarvis.mobile

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class PhoneActionExecutor(private val activity: Activity) {

    fun execute(action: JarvisAction): String = when (action) {
        is JarvisAction.OpenApp -> openApp(action.appName)
        is JarvisAction.OpenUrl -> launch(Intent(Intent.ACTION_VIEW, Uri.parse(action.url)), "Opening website")
        is JarvisAction.WebSearch -> launch(
            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${Uri.encode(action.query)}")),
            "Searching for ${action.query}"
        )
        is JarvisAction.MapsSearch -> launch(
            Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=${Uri.encode(action.query)}")),
            "Opening maps"
        )
        JarvisAction.OpenCamera -> launch(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA), "Opening camera")
        JarvisAction.OpenWifiSettings -> launch(Intent(Settings.ACTION_WIFI_SETTINGS), "Opening Wi-Fi settings")
        JarvisAction.OpenBluetoothSettings -> launch(Intent(Settings.ACTION_BLUETOOTH_SETTINGS), "Opening Bluetooth settings")
        is JarvisAction.Dial -> launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${action.number}")), "Opening dialer")
        is JarvisAction.Call -> makeCall(action.number)
        is JarvisAction.SetAlarm -> {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, action.hour)
                .putExtra(AlarmClock.EXTRA_MINUTES, action.minute)
                .putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS alarm")
            launch(intent, "Preparing alarm")
        }
        is JarvisAction.Unknown -> "I do not have a module for that command yet."
    }

    private fun openApp(name: String): String {
        val pm = activity.packageManager
        val apps = pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0))
        val match = apps.firstOrNull {
            pm.getApplicationLabel(it).toString().equals(name, true)
        } ?: apps.firstOrNull {
            pm.getApplicationLabel(it).toString().contains(name, true)
        } ?: return "I couldn't find $name."

        val intent = pm.getLaunchIntentForPackage(match.packageName)
            ?: return "$name cannot be launched normally."

        activity.startActivity(intent)
        return "Opening ${pm.getApplicationLabel(match)}."
    }

    private fun makeCall(number: String): String {
        if (ContextCompat.checkSelfPermission(activity, Manifest.permission.CALL_PHONE)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(activity, arrayOf(Manifest.permission.CALL_PHONE), 22)
            return "Call permission requested. Repeat the command after granting it."
        }
        activity.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")))
        return "Calling $number."
    }

    private fun launch(intent: Intent, success: String): String {
        return try {
            activity.startActivity(intent)
            "$success."
        } catch (_: Exception) {
            "No compatible Android app is available for that action."
        }
    }
}
