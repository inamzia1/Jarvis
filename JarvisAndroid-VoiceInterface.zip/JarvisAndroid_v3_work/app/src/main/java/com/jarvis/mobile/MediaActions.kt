package com.jarvis.mobile

sealed class MediaCommand {
    data object Play : MediaCommand()
    data object Pause : MediaCommand()
    data object Next : MediaCommand()
    data object Previous : MediaCommand()
    data object Toggle : MediaCommand()
    data class VolumePercent(val percent: Int) : MediaCommand()
    data object VolumeUp : MediaCommand()
    data object VolumeDown : MediaCommand()
    data object Mute : MediaCommand()
    data object Unmute : MediaCommand()
    data class LaunchMediaApp(val appName: String) : MediaCommand()
}
