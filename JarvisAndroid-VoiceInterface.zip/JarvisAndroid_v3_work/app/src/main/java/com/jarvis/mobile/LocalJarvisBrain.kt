package com.jarvis.mobile

import org.json.JSONObject

class LocalJarvisBrain {

    fun plan(
        input: String,
        memory: List<BrainTurn>
    ): BrainPlan {
        val conversational = conversationalReply(input)
        if (conversational != null) {
            return BrainPlan(
                reply = conversational,
                toolCalls = emptyList(),
                needsConfirmation = false
            )
        }

        val chunks = input
            .split(Regex("""\s+(?:and then|then|and)\s+""", RegexOption.IGNORE_CASE))
            .map { it.trim() }
            .filter { it.isNotBlank() }

        val calls = mutableListOf<BrainToolCall>()

        chunks.forEach { chunk ->
            parseOne(chunk)?.let { calls += it }
        }

        if (calls.isEmpty()) {
            val contextHint = memory.lastOrNull()?.text
            return BrainPlan(
                reply = buildString {
                    append("I understood the request, but local mode does not have a matching capability yet.")
                    if (!contextHint.isNullOrBlank()) {
                        append(" I retained the recent conversation context.")
                    }
                    append(" Connect a remote reasoning backend in Brain Settings for broader language understanding.")
                },
                toolCalls = emptyList(),
                needsConfirmation = false
            )
        }

        val needsConfirmation = calls.any {
            it.risk == BrainRisk.MEDIUM || it.risk == BrainRisk.HIGH
        }

        return BrainPlan(
            reply = "I prepared ${calls.size} action${if (calls.size == 1) "" else "s"}.",
            toolCalls = calls,
            needsConfirmation = needsConfirmation
        )
    }

    private fun conversationalReply(input: String): String? {
        val lower = input.trim().lowercase()

        if (lower in listOf("what can you do", "what can u do", "help", "your capabilities", "capabilities")) {
            return "I can control supported phone functions, open apps, search the web, navigate with maps, prepare messages, read your permitted calendar and notifications, manage authorized files, control media and volume, set reminders, and open camera vision. I can also build multi-step action plans. For broader free-form reasoning, connect a remote AI backend in AI Brain settings."
        }

        if (lower in listOf("who are you", "what are you")) {
            return "I am JARVIS, your Android assistant. I combine voice commands, phone tools, local memory, and an optional remote reasoning brain."
        }

        if (lower in listOf("hello", "hi", "hey", "hey jarvis", "hello jarvis")) {
            return "Hello. JARVIS is online and ready."
        }

        if (lower.contains("are you online") || lower.contains("system status")) {
            return "Core JARVIS systems are online. Some capabilities still depend on Android permissions and any remote AI backend you configure."
        }

        return null
    }

    private fun parseOne(text: String): BrainToolCall? {
        val lower = text.lowercase()

        Regex("""(?:open|launch)\s+(.+)""", RegexOption.IGNORE_CASE)
            .find(text)?.let {
                val app = it.groupValues[1].trim()
                if (
                    app !in listOf(
                        "files",
                        "file manager",
                        "vision",
                        "notifications"
                    )
                ) {
                    return call(
                        "open_app",
                        JSONObject().put("app_name", app),
                        "Open requested app."
                    )
                }
            }

        Regex("""(?:search(?: the web)? for|google)\s+(.+)""", RegexOption.IGNORE_CASE)
            .find(text)?.let {
                return call(
                    "web_search",
                    JSONObject().put("query", it.groupValues[1].trim()),
                    "Search requested topic."
                )
            }

        Regex("""(?:navigate|directions|go) to\s+(.+)""", RegexOption.IGNORE_CASE)
            .find(text)?.let {
                return call(
                    "navigate",
                    JSONObject().put("destination", it.groupValues[1].trim()),
                    "Open navigation."
                )
            }

        Regex("""call\s+([+\d][\d\s\-]+)""", RegexOption.IGNORE_CASE)
            .find(text)?.let {
                return call(
                    "call",
                    JSONObject().put("number", normalizeNumber(it.groupValues[1])),
                    "Phone call is externally consequential."
                )
            }

        Regex("""dial\s+([+\d][\d\s\-]+)""", RegexOption.IGNORE_CASE)
            .find(text)?.let {
                return call(
                    "dial",
                    JSONObject().put("number", normalizeNumber(it.groupValues[1])),
                    "Open dialer."
                )
            }

        Regex(
            """(?:text|sms|message)\s+(.+?)\s+(?:saying|that|:)\s*(.+)""",
            RegexOption.IGNORE_CASE
        ).find(text)?.let {
            return call(
                "compose_sms",
                JSONObject()
                    .put("recipient", it.groupValues[1].trim())
                    .put("body", it.groupValues[2].trim()),
                "Prepare an outgoing SMS."
            )
        }

        Regex(
            """whatsapp\s+(.+?)\s+(?:saying|that|:)\s*(.+)""",
            RegexOption.IGNORE_CASE
        ).find(text)?.let {
            return call(
                "compose_whatsapp",
                JSONObject()
                    .put("recipient", it.groupValues[1].trim())
                    .put("body", it.groupValues[2].trim()),
                "Prepare an outgoing WhatsApp message."
            )
        }

        if (
            lower.contains("what's on today") ||
            lower.contains("whats on today") ||
            lower.contains("today's schedule") ||
            lower.contains("todays schedule")
        ) {
            return call(
                "calendar_today",
                JSONObject(),
                "Read today's calendar."
            )
        }

        if (
            lower.contains("this week's schedule") ||
            lower.contains("this weeks schedule") ||
            lower.contains("next seven days")
        ) {
            return call(
                "calendar_week",
                JSONObject(),
                "Read upcoming calendar."
            )
        }

        Regex(
            """remind me in (\d+)\s+minutes?\s+(?:to\s+)?(.+)""",
            RegexOption.IGNORE_CASE
        ).find(text)?.let {
            return call(
                "set_reminder_minutes",
                JSONObject()
                    .put("minutes", it.groupValues[1].toInt())
                    .put("text", it.groupValues[2].trim()),
                "Create a reminder."
            )
        }

        when {
            lower in listOf("play", "play music", "resume music") ->
                return media("play")
            lower in listOf("pause", "pause music") ->
                return media("pause")
            lower in listOf("next", "next song", "skip song") ->
                return media("next")
            lower in listOf("previous", "previous song") ->
                return media("previous")
        }

        Regex(
            """(?:set\s+)?volume(?:\s+to)?\s+(\d{1,3})\s*%?""",
            RegexOption.IGNORE_CASE
        ).find(text)?.let {
            return call(
                "volume",
                JSONObject().put(
                    "percent",
                    it.groupValues[1].toInt().coerceIn(0, 100)
                ),
                "Adjust media volume."
            )
        }

        Regex(
            """(?:find|search for|locate)\s+(?:file\s+)?(.+)""",
            RegexOption.IGNORE_CASE
        ).find(text)?.let {
            return call(
                "find_file",
                JSONObject().put("query", it.groupValues[1].trim()),
                "Search authorized files."
            )
        }

        if (lower in listOf("open files", "open file manager", "show files")) {
            return call("open_files", JSONObject(), "Open file manager.")
        }

        if (lower.contains("vision") || lower == "take a photo") {
            return call("open_vision", JSONObject(), "Open vision module.")
        }

        if (lower.contains("notifications") || lower == "show messages") {
            return call(
                "open_notifications",
                JSONObject(),
                "Open notification inbox."
            )
        }

        return null
    }

    private fun media(command: String) =
        call(
            "media",
            JSONObject().put("command", command),
            "Control active playback."
        )

    private fun call(
        tool: String,
        args: JSONObject,
        reason: String
    ): BrainToolCall =
        BrainToolCall(
            tool = tool,
            arguments = args,
            risk = BrainToolRegistry.riskFor(tool),
            reason = reason
        )

    private fun normalizeNumber(raw: String): String =
        raw.replace(" ", "").replace("-", "")
}
