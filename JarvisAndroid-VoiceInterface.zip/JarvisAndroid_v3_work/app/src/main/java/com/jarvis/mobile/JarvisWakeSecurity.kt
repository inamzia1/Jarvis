package com.jarvis.mobile

import android.content.Context

enum class WakeAuthResult { UNLOCKED, WRONG_PIN, PIN_NOT_CONFIGURED }

class JarvisWakeSecurity(context: Context) {
    private val pin = VoicePinGate(context)
    private val prefs = context.getSharedPreferences("jarvis_voice_pin", Context.MODE_PRIVATE)

    fun authenticate(spokenSecret: String): WakeAuthResult {
        if (!pin.hasPin()) return WakeAuthResult.PIN_NOT_CONFIGURED

        return if (pin.verify(spokenSecret.trim())) {
            prefs.edit().putInt("failed_attempts", 0).apply()
            OwnerSession.markAuthenticated()
            WakeAuthResult.UNLOCKED
        } else {
            val failures = prefs.getInt("failed_attempts", 0) + 1
            prefs.edit().putInt("failed_attempts", failures).apply()
            OwnerSession.lock()
            WakeAuthResult.WRONG_PIN
        }
    }

    fun prompt(): String =
        if (pin.hasPin()) "Voice authorization required. Please say your JARVIS password."
        else "No JARVIS voice password is configured. Open JARVIS and set one first."
}
