package com.jarvis.mobile

import android.app.Activity
import android.content.Intent
import android.net.Uri
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

sealed class MessagingResult {
    data class Success(val message: String) : MessagingResult()
    data class NeedsContactPermission(val contactName: String) : MessagingResult()
    data class NeedsDisambiguation(
        val app: String,
        val body: String,
        val matches: List<ContactMatch>
    ) : MessagingResult()
    data class Failure(val message: String) : MessagingResult()
}

class MessagingExecutor(
    private val activity: Activity,
    private val contacts: ContactResolver
) {

    fun execute(action: MessagingAction): MessagingResult {
        return when (action) {
            is MessagingAction.ComposeSms ->
                composeSms(action.recipient, action.body)

            is MessagingAction.ComposeWhatsApp ->
                composeWhatsApp(action.recipient, action.body)

            is MessagingAction.ResolveAndComposeSms ->
                resolveContact("sms", action.contactName, action.body)

            is MessagingAction.ResolveAndComposeWhatsApp ->
                resolveContact("whatsapp", action.contactName, action.body)
        }
    }

    private fun resolveContact(
        app: String,
        contactName: String,
        body: String
    ): MessagingResult {
        if (!contacts.hasPermission()) {
            return MessagingResult.NeedsContactPermission(contactName)
        }

        val matches = contacts.findByName(contactName)

        if (matches.isEmpty()) {
            return MessagingResult.Failure("I couldn't find a contact matching $contactName.")
        }

        if (matches.size > 1) {
            return MessagingResult.NeedsDisambiguation(app, body, matches)
        }

        val match = matches.first()
        return if (app == "sms") {
            composeSms(match.phoneNumber, body)
        } else {
            composeWhatsApp(match.phoneNumber, body)
        }
    }

    fun composeSms(number: String, body: String): MessagingResult {
        val uri = Uri.parse("smsto:${Uri.encode(number)}")
        val intent = Intent(Intent.ACTION_SENDTO, uri).apply {
            putExtra("sms_body", body)
        }

        return try {
            activity.startActivity(intent)
            MessagingResult.Success(
                "SMS prepared for $number. Review it in your messaging app before sending."
            )
        } catch (_: Exception) {
            MessagingResult.Failure("No SMS app is available.")
        }
    }

    fun composeWhatsApp(number: String?, body: String): MessagingResult {
        val encoded = URLEncoder.encode(body, StandardCharsets.UTF_8.toString())
        val normalized = number
            ?.filter { it.isDigit() || it == '+' }
            ?.replace("+", "")

        val url = if (normalized.isNullOrBlank()) {
            "https://wa.me/?text=$encoded"
        } else {
            "https://wa.me/$normalized?text=$encoded"
        }

        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            setPackage("com.whatsapp")
        }

        return try {
            activity.startActivity(intent)
            MessagingResult.Success(
                "WhatsApp message prepared. Review it in WhatsApp before sending."
            )
        } catch (_: Exception) {
            try {
                activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                MessagingResult.Success(
                    "Opening WhatsApp-compatible message link for review."
                )
            } catch (_: Exception) {
                MessagingResult.Failure("WhatsApp or a compatible handler is unavailable.")
            }
        }
    }
}
