package com.jarvis.mobile

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class RemoteJarvisBrain {

    fun plan(
        mode: BrainMode.Remote,
        input: String,
        memory: List<BrainTurn>,
        longTermFacts: List<String> = emptyList()
    ): Result<BrainPlan> {
        return try {
            val connection = URL(mode.endpoint).openConnection() as HttpURLConnection
            connection.requestMethod = "POST"
            connection.connectTimeout = 20_000
            connection.readTimeout = 40_000
            connection.doOutput = true
            connection.setRequestProperty("Content-Type", "application/json")

            mode.bearerToken?.let {
                connection.setRequestProperty("Authorization", "Bearer $it")
            }

            val body = JSONObject().apply {
                put("input", input)
                put(
                    "long_term_memory",
                    JSONArray().apply {
                        longTermFacts.takeLast(100).forEach { put(it) }
                    }
                )
                put("tools", BrainToolRegistry.asJson())
                put(
                    "memory",
                    JSONArray().apply {
                        memory.takeLast(12).forEach { turn ->
                            put(
                                JSONObject()
                                    .put("role", turn.role)
                                    .put("text", turn.text)
                            )
                        }
                    }
                )
                put(
                    "policy",
                    JSONObject()
                        .put("require_approval_for_medium", true)
                        .put("require_approval_for_high", true)
                        .put("max_tool_calls", 8)
                )
            }

            connection.outputStream.use {
                it.write(body.toString().toByteArray(Charsets.UTF_8))
            }

            val code = connection.responseCode
            val stream =
                if (code in 200..299) connection.inputStream
                else connection.errorStream

            val responseText = BufferedReader(
                InputStreamReader(stream)
            ).use { it.readText() }

            if (code !in 200..299) {
                return Result.failure(
                    IllegalStateException(
                        "Brain backend returned HTTP $code: $responseText"
                    )
                )
            }

            val json = JSONObject(responseText)
            val reply = json.optString(
                "reply",
                "I prepared a plan."
            )

            val calls = mutableListOf<BrainToolCall>()
            val arr = json.optJSONArray("tool_calls") ?: JSONArray()

            for (i in 0 until arr.length()) {
                val item = arr.getJSONObject(i)
                val tool = item.getString("tool")
                val args = item.optJSONObject("arguments") ?: JSONObject()
                val declaredRisk =
                    try {
                        BrainRisk.valueOf(
                            item.optString(
                                "risk",
                                BrainToolRegistry.riskFor(tool).name
                            )
                        )
                    } catch (_: Exception) {
                        BrainToolRegistry.riskFor(tool)
                    }

                // Never allow a backend to downgrade local tool risk.
                val localRisk = BrainToolRegistry.riskFor(tool)
                val effectiveRisk =
                    if (localRisk.ordinal > declaredRisk.ordinal)
                        localRisk
                    else
                        declaredRisk

                calls += BrainToolCall(
                    tool = tool,
                    arguments = args,
                    risk = effectiveRisk,
                    reason = item.optString(
                        "reason",
                        "Remote brain requested this tool."
                    )
                )
            }

            if (calls.size > 8) {
                return Result.failure(
                    IllegalStateException("Backend requested too many tool calls.")
                )
            }

            val memoryUpdates = mutableListOf<String>()
            val memoryArray = json.optJSONArray("memory_updates") ?: JSONArray()
            for (i in 0 until memoryArray.length()) {
                val fact = memoryArray.optString(i).trim()
                if (fact.isNotBlank()) memoryUpdates += fact
            }

            Result.success(
                BrainPlan(
                    reply = reply,
                    toolCalls = calls,
                    needsConfirmation = calls.any {
                        it.risk != BrainRisk.LOW
                    },
                    memoryUpdates = memoryUpdates
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun finalize(
        mode: BrainMode.Remote,
        input: String,
        memory: List<BrainTurn>,
        outputs: List<BrainToolOutput>,
        longTermFacts: List<String> = emptyList()
    ): Result<String> {
        return try {
            val endpoint = if (mode.endpoint.endsWith("/jarvis/plan")) {
                mode.endpoint.removeSuffix("/jarvis/plan") + "/jarvis/finalize"
            } else {
                mode.endpoint.trimEnd('/') + "/finalize"
            }

            val connection = URL(endpoint).openConnection() as HttpURLConnection
            connection.requestMethod = "POST"
            connection.connectTimeout = 20_000
            connection.readTimeout = 40_000
            connection.doOutput = true
            connection.setRequestProperty("Content-Type", "application/json")

            mode.bearerToken?.let {
                connection.setRequestProperty("Authorization", "Bearer $it")
            }

            val body = JSONObject().apply {
                put("input", input)
                put(
                    "long_term_memory",
                    JSONArray().apply {
                        longTermFacts.takeLast(100).forEach { put(it) }
                    }
                )
                put(
                    "memory",
                    JSONArray().apply {
                        memory.takeLast(10).forEach { turn ->
                            put(
                                JSONObject()
                                    .put("role", turn.role)
                                    .put("text", turn.text)
                            )
                        }
                    }
                )
                put(
                    "tool_outputs",
                    JSONArray().apply {
                        outputs.forEach { output ->
                            put(
                                JSONObject()
                                    .put("tool", output.tool)
                                    .put("output", output.output)
                            )
                        }
                    }
                )
            }

            connection.outputStream.use {
                it.write(body.toString().toByteArray(Charsets.UTF_8))
            }

            val code = connection.responseCode
            val stream =
                if (code in 200..299) connection.inputStream
                else connection.errorStream

            val responseText = BufferedReader(
                InputStreamReader(stream)
            ).use { it.readText() }

            if (code !in 200..299) {
                return Result.failure(
                    IllegalStateException(
                        "Brain finalize backend returned HTTP $code: $responseText"
                    )
                )
            }

            Result.success(
                JSONObject(responseText).optString("reply", "Done.")
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

}
