package com.jarvis.mobile

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import com.jarvis.mobile.databinding.ActivityMediaBinding

class MediaActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMediaBinding
    private lateinit var engine: MediaControllerEngine

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMediaBinding.inflate(layoutInflater)
        setContentView(binding.root)

        engine = MediaControllerEngine(this)

        binding.previousButton.setOnClickListener {
            engine.execute(MediaCommand.Previous)
            refresh()
        }

        binding.playPauseButton.setOnClickListener {
            engine.execute(MediaCommand.Toggle)
            refresh()
        }

        binding.nextButton.setOnClickListener {
            engine.execute(MediaCommand.Next)
            refresh()
        }

        binding.spotifyButton.setOnClickListener {
            binding.sessionText.text =
                engine.execute(MediaCommand.LaunchMediaApp("spotify"))
        }

        binding.youtubeMusicButton.setOnClickListener {
            binding.sessionText.text =
                engine.execute(MediaCommand.LaunchMediaApp("youtube music"))
        }

        binding.mediaAccessButton.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        binding.volumeSeek.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(
                    seekBar: SeekBar?,
                    progress: Int,
                    fromUser: Boolean
                ) {
                    binding.volumeText.text = "Volume: $progress%"
                    if (fromUser) {
                        engine.execute(MediaCommand.VolumePercent(progress))
                    }
                }

                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            }
        )
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        binding.sessionText.text = engine.currentSessionSummary()
    }
}
