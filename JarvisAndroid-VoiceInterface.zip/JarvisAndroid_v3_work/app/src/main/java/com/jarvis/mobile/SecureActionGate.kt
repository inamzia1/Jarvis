package com.jarvis.mobile

import android.app.Activity

class SecureActionGate(private val activity: Activity) {
    private val auth = OwnerAuthManager(activity)

    fun runProtected(
        description: String,
        action: () -> Unit,
        onDenied: (String) -> Unit = {}
    ) {
        if (OwnerSession.isAuthenticated()) {
            action()
            return
        }

        auth.authenticate(
            title = "Owner verification",
            subtitle = description,
            onSuccess = {
                OwnerSession.markAuthenticated()
                action()
            },
            onFailure = onDenied
        )
    }
}
