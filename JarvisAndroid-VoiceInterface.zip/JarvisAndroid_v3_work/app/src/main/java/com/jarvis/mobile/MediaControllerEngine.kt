package com.jarvis.mobile

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.media.AudioManager
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.provider.Settings
import android.content.Intent

class MediaControllerEngine(private val activity: Activity) {

    private val audioManager =
        activity.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private val mediaSessionManager =
        activity.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager

    private fun listenerComponent(): ComponentName =
        ComponentName(activity, JarvisNotificationListener::class.java)

    fun hasNotificationAccess(): Boolean {
        val enabled = Settings.Secure.getString(
            activity.contentResolver,
            "enabled_notification_listeners"
        ) ?: return false
        return enabled.contains(activity.packageName)
    }

    fun execute(command: MediaCommand): String {
        return when (command) {
            MediaCommand.Play -> transport { it.play() } ?: "No active media session found."
            MediaCommand.Pause -> transport { it.pause() } ?: "No active media session found."
            MediaCommand.Next -> transport { it.skipToNext() } ?: "No active media session found."
            MediaCommand.Previous -> transport { it.skipToPrevious() } ?: "No active media session found."
            MediaCommand.Toggle -> togglePlayback()
            is MediaCommand.VolumePercent -> setVolume(command.percent)
            MediaCommand.VolumeUp -> adjustVolume(AudioManager.ADJUST_RAISE)
            MediaCommand.VolumeDown -> adjustVolume(AudioManager.ADJUST_LOWER)
            MediaCommand.Mute -> adjustVolume(AudioManager.ADJUST_MUTE)
            MediaCommand.Unmute -> adjustVolume(AudioManager.ADJUST_UNMUTE)
            is MediaCommand.LaunchMediaApp -> launchApp(command.appName)
        }
    }

    private fun activeControllers(): List<MediaController> {
        if (!hasNotificationAccess()) return emptyList()
        return try {
            mediaSessionManager.getActiveSessions(listenerComponent())
        } catch (_: SecurityException) {
            emptyList()
        }
    }

    private fun topController(): MediaController? {
        val sessions = activeControllers()
        if (sessions.isEmpty()) return null

        return sessions.firstOrNull {
            val state = it.playbackState?.state
            state == PlaybackState.STATE_PLAYING ||
            state == PlaybackState.STATE_BUFFERING
        } ?: sessions.firstOrNull()
    }

    private fun transport(block: (MediaController.TransportControls) -> Unit): String? {
        val controller = topController() ?: return null
        block(controller.transportControls)

        val label = try {
            val app = activity.packageManager.getApplicationInfo(
                controller.packageName, 0
            )
            activity.packageManager.getApplicationLabel(app).toString()
        } catch (_: Exception) {
            controller.packageName
        }

        return "Media command sent to $label."
    }

    private fun togglePlayback(): String {
        val controller = topController()
            ?: return "No active media session found."

        val state = controller.playbackState?.state

        return if (
            state == PlaybackState.STATE_PLAYING ||
            state == PlaybackState.STATE_BUFFERING
        ) {
            controller.transportControls.pause()
            "Playback paused."
        } else {
            controller.transportControls.play()
            "Playback resumed."
        }
    }

    private fun setVolume(percent: Int): String {
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val target = ((percent / 100.0) * max).toInt().coerceIn(0, max)

        return try {
            audioManager.setStreamVolume(
                AudioManager.STREAM_MUSIC,
                target,
                AudioManager.FLAG_SHOW_UI
            )
            "Media volume set to $percent percent."
        } catch (e: SecurityException) {
            "Android blocked direct volume control on this device."
        }
    }

    private fun adjustVolume(direction: Int): String {
        return try {
            audioManager.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                direction,
                AudioManager.FLAG_SHOW_UI
            )
            when (direction) {
                AudioManager.ADJUST_RAISE -> "Media volume increased."
                AudioManager.ADJUST_LOWER -> "Media volume decreased."
                AudioManager.ADJUST_MUTE -> "Media muted."
                AudioManager.ADJUST_UNMUTE -> "Media unmuted."
                else -> "Media volume adjusted."
            }
        } catch (_: SecurityException) {
            "Android blocked that volume action on this device."
        }
    }

    private fun launchApp(appName: String): String {
        val aliases = mapOf(
            "spotify" to "com.spotify.music",
            "youtube music" to "com.google.android.apps.youtube.music",
            "yt music" to "com.google.android.apps.youtube.music",
            "apple music" to "com.apple.android.music",
            "soundcloud" to "com.soundcloud.android"
        )

        val packageName = aliases[appName.lowercase()]
            ?: return "I don't know that media app yet."

        val intent = activity.packageManager.getLaunchIntentForPackage(packageName)

        return if (intent != null) {
            activity.startActivity(intent)
            "Opening $appName."
        } else {
            "I couldn't find $appName installed."
        }
    }

    fun currentSessionSummary(): String {
        val controller = topController()
            ?: return if (hasNotificationAccess())
                "No active media session."
            else
                "Notification access is required for media session control."

        val metadata = controller.metadata
        val title = metadata?.getString(android.media.MediaMetadata.METADATA_KEY_TITLE)
            ?: "Unknown title"
        val artist = metadata?.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST)
            ?: "Unknown artist"

        val state = when (controller.playbackState?.state) {
            PlaybackState.STATE_PLAYING -> "PLAYING"
            PlaybackState.STATE_PAUSED -> "PAUSED"
            PlaybackState.STATE_BUFFERING -> "BUFFERING"
            else -> "IDLE"
        }

        return "$state · $title · $artist"
    }
}
