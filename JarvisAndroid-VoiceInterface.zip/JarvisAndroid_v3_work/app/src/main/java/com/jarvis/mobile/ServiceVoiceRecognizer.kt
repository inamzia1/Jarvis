package com.jarvis.mobile

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

// Wake command: JARVIS
class ServiceVoiceRecognizer(
    private val context: Context,
    private val onPhrase: (String) -> Unit,
    private val onState: (String) -> Unit
) {
    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var active = true
    private var listening = false

    fun startLoop() {
        active = true
        handler.post { listen() }
    }

    private fun listen() {
        if (!active || listening) return
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onState("Speech recognition unavailable")
            return
        }

        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        onState("Listening for “Jarvis”…")
                    }
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() { onState("Processing voice…") }

                    override fun onError(error: Int) {
                        listening = false
                        if (active) handler.postDelayed({ listen() }, 700)
                    }

                    override fun onResults(results: Bundle?) {
                        listening = false
                        results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()
                            ?.takeIf { it.isNotBlank() }
                            ?.let(onPhrase)
                        if (active) handler.postDelayed({ listen() }, 450)
                    }

                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            // Let Android recognition use multilingual/system language when supported.
            // The LLM handles English, Urdu, Hindi and Roman Urdu/Hindi.
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-GB,ur-PK,hi-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }

        try {
            listening = true
            recognizer?.startListening(intent)
        } catch (_: Exception) {
            listening = false
            handler.postDelayed({ listen() }, 1000)
        }
    }

    fun destroy() {
        active = false
        listening = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
    }
}
