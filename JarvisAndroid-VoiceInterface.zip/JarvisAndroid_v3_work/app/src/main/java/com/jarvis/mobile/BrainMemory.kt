package com.jarvis.mobile

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class BrainMemory(private val context: Context) {

    companion object {
        private const val PREFS = "jarvis_brain_memory"
        private const val KEY_TURNS = "turns"
        private const val MAX_TURNS = 30
    }

    fun add(role: String, text: String) {
        val turns = load().toMutableList()
        turns += BrainTurn(role, text)
        save(turns.takeLast(MAX_TURNS))
    }

    fun load(): List<BrainTurn> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_TURNS, null)
            ?: return emptyList()

        return try {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    add(
                        BrainTurn(
                            role = o.optString("role"),
                            text = o.optString("text"),
                            timestamp = o.optLong("timestamp")
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun clear() {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .remove(KEY_TURNS)
            .apply()
    }

    private fun save(turns: List<BrainTurn>) {
        val arr = JSONArray()
        turns.forEach { turn ->
            arr.put(
                JSONObject().apply {
                    put("role", turn.role)
                    put("text", turn.text)
                    put("timestamp", turn.timestamp)
                }
            )
        }

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_TURNS, arr.toString())
            .apply()
    }
}
