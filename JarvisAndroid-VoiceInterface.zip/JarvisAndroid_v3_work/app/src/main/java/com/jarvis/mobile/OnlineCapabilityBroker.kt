package com.jarvis.mobile

import android.content.Context
import android.content.Intent
import android.net.Uri

class OnlineCapabilityBroker(private val context: Context) {

    fun openUrl(url: String): String {
        val safe = when {
            url.startsWith("https://") -> url
            url.startsWith("http://") -> url
            else -> "https://$url"
        }

        return try {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(safe)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            "Opened $safe"
        } catch (_: Exception) {
            "I couldn't open that link."
        }
    }

    fun searchWeb(query: String): String {
        val uri = Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}")
        return try {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            "Searching the web for $query."
        } catch (_: Exception) {
            "I couldn't open web search."
        }
    }
}
