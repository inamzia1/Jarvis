package com.jarvis.mobile

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import kotlin.math.max

class LocalVisionInspector(private val context: Context) {

    fun inspect(uri: Uri): Result<VisionImage> {
        return try {
            val resolver = context.contentResolver

            val bounds = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }

            resolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, bounds)
            }

            val width = bounds.outWidth
            val height = bounds.outHeight

            if (width <= 0 || height <= 0) {
                return Result.failure(
                    IllegalArgumentException("Unable to decode this image.")
                )
            }

            val sample = calculateSampleSize(width, height, 512)

            val options = BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = android.graphics.Bitmap.Config.ARGB_8888
            }

            val bitmap = resolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, options)
            } ?: return Result.failure(
                IllegalArgumentException("Unable to load this image.")
            )

            var total = 0L
            var count = 0L
            val stepX = max(1, bitmap.width / 64)
            val stepY = max(1, bitmap.height / 64)

            var y = 0
            while (y < bitmap.height) {
                var x = 0
                while (x < bitmap.width) {
                    val pixel = bitmap.getPixel(x, y)
                    val r = android.graphics.Color.red(pixel)
                    val g = android.graphics.Color.green(pixel)
                    val b = android.graphics.Color.blue(pixel)

                    // Approximate perceived luminance
                    val luma = (0.2126 * r + 0.7152 * g + 0.0722 * b).toInt()
                    total += luma
                    count++
                    x += stepX
                }
                y += stepY
            }

            bitmap.recycle()

            val averageLuma =
                if (count == 0L) 0 else (total / count).toInt()

            val mimeType =
                resolver.getType(uri) ?: "image/*"

            val sizeBytes = querySize(uri)

            val orientation =
                when {
                    width > height -> "Landscape"
                    height > width -> "Portrait"
                    else -> "Square"
                }

            Result.success(
                VisionImage(
                    uri = uri,
                    width = width,
                    height = height,
                    sizeBytes = sizeBytes,
                    mimeType = mimeType,
                    averageLuma = averageLuma,
                    orientation = orientation
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun analyze(image: VisionImage): VisionAnalysis {
        val warnings = mutableListOf<String>()

        if (image.width < 720 || image.height < 720) {
            warnings += "Image resolution is relatively low for detailed visual analysis."
        }

        if (image.averageLuma < 45) {
            warnings += "Image appears quite dark."
        } else if (image.averageLuma > 225) {
            warnings += "Image appears heavily overexposed or very bright."
        }

        if (image.sizeBytes > 15L * 1024L * 1024L) {
            warnings += "Image is large and may be expensive to upload to a remote vision model."
        }

        val brightness =
            when {
                image.averageLuma < 70 -> "dark"
                image.averageLuma > 190 -> "bright"
                else -> "normally lit"
            }

        val summary =
            "${image.orientation} ${image.width}×${image.height} image. " +
            "It appears $brightness and is ready for deeper AI vision analysis."

        val prompt =
            "Describe the scene, identify important objects/text, explain anything unusual, " +
            "and suggest any useful actions JARVIS should take."

        return VisionAnalysis(
            summary = summary,
            warnings = warnings,
            suggestedPrompt = prompt
        )
    }

    private fun querySize(uri: Uri): Long {
        return context.contentResolver.query(
            uri,
            arrayOf(OpenableColumns.SIZE),
            null,
            null,
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (index >= 0 && !cursor.isNull(index)) cursor.getLong(index) else 0L
            } else 0L
        } ?: 0L
    }

    private fun calculateSampleSize(
        width: Int,
        height: Int,
        target: Int
    ): Int {
        var sample = 1
        while (width / sample > target * 2 || height / sample > target * 2) {
            sample *= 2
        }
        return sample
    }
}
