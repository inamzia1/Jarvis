package com.jarvis.mobile

import android.app.KeyguardManager
import android.content.Context
import androidx.biometric.BiometricManager

enum class ActionRisk { LOW, MEDIUM, HIGH }

object JarvisSecurity {
    private val highRisk = setOf(
        "send_message", "send_email", "make_call", "delete_file",
        "create_payment", "change_security_setting", "install_app",
        "uninstall_app", "share_private_data"
    )

    fun classify(tool: String): ActionRisk =
        if (tool.lowercase() in highRisk) ActionRisk.HIGH else ActionRisk.LOW

    fun requiresConfirmation(tool: String): Boolean = classify(tool) == ActionRisk.HIGH

    fun deviceSecure(context: Context): Boolean {
        val km = context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        return km.isDeviceSecure
    }

    fun biometricsAvailable(context: Context): Boolean {
        val bm = BiometricManager.from(context)
        return bm.canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_STRONG or
            BiometricManager.Authenticators.DEVICE_CREDENTIAL
        ) == BiometricManager.BIOMETRIC_SUCCESS
    }
}
