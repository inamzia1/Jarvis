package com.jarvis.mobile

import android.content.Context

class BrainSettings(private val context: Context) {

    companion object {
        private const val PREFS = "jarvis_brain_settings"
        private const val KEY_ENDPOINT = "endpoint"
        private const val KEY_TOKEN = "token"
        private const val KEY_REMOTE_ENABLED = "remote_enabled"
    }

    fun mode(): BrainMode {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val enabled = prefs.getBoolean(KEY_REMOTE_ENABLED, false)
        val endpoint = prefs.getString(KEY_ENDPOINT, "").orEmpty().trim()
        val token = prefs.getString(KEY_TOKEN, "").orEmpty().trim()

        return if (enabled && endpoint.isNotBlank()) {
            BrainMode.Remote(
                endpoint = endpoint,
                bearerToken = token.ifBlank { null }
            )
        } else {
            BrainMode.Local
        }
    }

    fun save(
        remoteEnabled: Boolean,
        endpoint: String,
        token: String
    ) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_REMOTE_ENABLED, remoteEnabled)
            .putString(KEY_ENDPOINT, endpoint.trim())
            .putString(KEY_TOKEN, token.trim())
            .apply()
    }

    fun currentEndpoint(): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_ENDPOINT, "")
            .orEmpty()

    fun currentToken(): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_TOKEN, "")
            .orEmpty()

    fun remoteEnabled(): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_REMOTE_ENABLED, false)
}
