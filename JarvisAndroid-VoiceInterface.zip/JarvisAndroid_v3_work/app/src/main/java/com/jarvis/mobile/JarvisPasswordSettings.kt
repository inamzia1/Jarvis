package com.jarvis.mobile

import android.content.Context

sealed class PasswordChangeResult {
    data object Success : PasswordChangeResult()
    data class Error(val message: String) : PasswordChangeResult()
}

class JarvisPasswordSettings(context: Context) {
    private val gate = VoicePinGate(context)

    fun status(): String =
        if (gate.hasPin()) "JARVIS voice password is configured."
        else "No JARVIS voice password is configured."

    fun createPassword(newPassword: String, confirmation: String): PasswordChangeResult {
        if (gate.hasPin()) return PasswordChangeResult.Error("A password already exists. Use Change Password.")
        return validateAndSave(newPassword, confirmation)
    }

    fun changePassword(
        currentPassword: String,
        newPassword: String,
        confirmation: String
    ): PasswordChangeResult {
        if (!gate.hasPin()) return PasswordChangeResult.Error("No password is configured yet.")
        if (!gate.verify(currentPassword)) return PasswordChangeResult.Error("Current password is incorrect.")
        if (newPassword == currentPassword) return PasswordChangeResult.Error("Choose a different new password.")
        val validation = validate(newPassword, confirmation)
        if (validation != null) return PasswordChangeResult.Error(validation)
        gate.setPin(newPassword)
        OwnerSession.lock()
        return PasswordChangeResult.Success
    }

    fun removePassword(currentPassword: String): PasswordChangeResult {
        if (!gate.hasPin()) return PasswordChangeResult.Error("No password is configured.")
        return if (gate.removePin(currentPassword)) {
            OwnerSession.lock()
            PasswordChangeResult.Success
        } else PasswordChangeResult.Error("Current password is incorrect.")
    }

    private fun validateAndSave(password: String, confirmation: String): PasswordChangeResult {
        val validation = validate(password, confirmation)
        if (validation != null) return PasswordChangeResult.Error(validation)
        gate.setPin(password)
        OwnerSession.lock()
        return PasswordChangeResult.Success
    }

    private fun validate(password: String, confirmation: String): String? {
        if (password != confirmation) return "Passwords do not match."
        if (password.length < 6) return "Use at least 6 characters."
        if (password.length > 64) return "Password is too long."
        return null
    }
}
