package com.jarvis.mobile

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class BusinessStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("jarvis_business", Context.MODE_PRIVATE)

    fun leads(): List<BusinessLead> {
        val arr = JSONArray(prefs.getString("leads", "[]") ?: "[]")
        return (0 until arr.length()).mapNotNull { i ->
            try {
                val o = arr.getJSONObject(i)
                BusinessLead(
                    o.getLong("id"),
                    o.optString("name"),
                    o.optString("company"),
                    o.optString("status", "NEW"),
                    o.optDouble("value", 0.0),
                    o.optString("nextAction"),
                    o.optLong("createdAt")
                )
            } catch (_: Exception) { null }
        }
    }

    fun tasks(): List<BusinessTask> {
        val arr = JSONArray(prefs.getString("tasks", "[]") ?: "[]")
        return (0 until arr.length()).mapNotNull { i ->
            try {
                val o = arr.getJSONObject(i)
                BusinessTask(o.getLong("id"), o.optString("title"), o.optBoolean("completed"))
            } catch (_: Exception) { null }
        }
    }

    fun addLead(name: String, company: String, value: Double, nextAction: String) {
        val list = leads().toMutableList()
        list += BusinessLead(System.currentTimeMillis(), name, company, "NEW", value, nextAction, System.currentTimeMillis())
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject()
                .put("id", it.id).put("name", it.name).put("company", it.company)
                .put("status", it.status).put("value", it.value)
                .put("nextAction", it.nextAction).put("createdAt", it.createdAt))
        }
        prefs.edit().putString("leads", arr.toString()).apply()
    }

    fun addTask(title: String) {
        val list = tasks().toMutableList()
        list += BusinessTask(System.currentTimeMillis(), title, false)
        writeTasks(list)
    }

    fun toggleTask(id: Long) {
        writeTasks(tasks().map { if (it.id == id) it.copy(completed = !it.completed) else it })
    }

    private fun writeTasks(list: List<BusinessTask>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("title", it.title).put("completed", it.completed))
        }
        prefs.edit().putString("tasks", arr.toString()).apply()
    }

    fun snapshot(): BusinessSnapshot {
        val leads = leads()
        return BusinessSnapshot(
            activeLeads = leads.count { it.status != "WON" && it.status != "LOST" },
            pipelineValue = leads.filter { it.status != "LOST" }.sumOf { it.value },
            openTasks = tasks().count { !it.completed }
        )
    }

    fun summary(): String {
        val s = snapshot()
        return "Business dashboard: ${s.activeLeads} active leads, ${s.openTasks} open tasks, " +
            "pipeline value ${"%.0f".format(s.pipelineValue)}."
    }
}
