package com.jarvis.mobile

enum class RiskLevel { LOW, MEDIUM, HIGH }

sealed class JarvisAction(val risk: RiskLevel) {
    data class OpenApp(val appName: String) : JarvisAction(RiskLevel.LOW)
    data class OpenUrl(val url: String) : JarvisAction(RiskLevel.LOW)
    data class WebSearch(val query: String) : JarvisAction(RiskLevel.LOW)
    data class MapsSearch(val query: String) : JarvisAction(RiskLevel.LOW)
    data object OpenCamera : JarvisAction(RiskLevel.LOW)
    data object OpenWifiSettings : JarvisAction(RiskLevel.LOW)
    data object OpenBluetoothSettings : JarvisAction(RiskLevel.LOW)
    data class Dial(val number: String) : JarvisAction(RiskLevel.MEDIUM)
    data class Call(val number: String) : JarvisAction(RiskLevel.HIGH)
    data class SetAlarm(val hour: Int, val minute: Int) : JarvisAction(RiskLevel.MEDIUM)
    data class Unknown(val raw: String) : JarvisAction(RiskLevel.LOW)
}
