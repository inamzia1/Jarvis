# JARVIS v4.2 — Communication Intelligence

## Priority notifications
JARVIS now includes a local priority scorer for notifications. Urgent wording, calls,
messages and high-priority notifications are surfaced into a priority inbox.

## WhatsApp / Instagram generic replies
Android notification-listener support can use a messaging app's own notification
`RemoteInput` Reply action. This avoids screen scraping and does not bypass the app.

Auto-reply is OFF by default. The owner must explicitly enable it and choose which apps
are allowed. Default generic text:

> I'm unavailable right now. I'll get back to you as soon as I can.

The feature works only when the installed messaging app exposes a notification Reply action.

## Calls
JARVIS can recognize call/missed-call notifications and prepare a generic response.
It does not impersonate the owner by answering a voice/video call and speaking to a caller.
For WhatsApp/Instagram missed calls, a follow-up message can only be sent where the app
provides a supported notification reply path.

## Gmail
Gmail should use Google's official OAuth/API through the JARVIS backend. Do not put a
Google password or OAuth client secret inside the APK. The architecture includes a
ConnectedMessagingBroker for this integration.

## Safety
JARVIS does not mass-message people, bypass platform protections, scrape private app UI,
or silently send AI-generated commitments/payments/legal statements. Generic away replies
are intentionally narrow. More substantive replies should require owner review.
